-- Lobby character fallback.
-- The lobby's 3D character only finishes loading with a weapon the menus can stream. The game swaps the Jet Gun
-- for a BO6 rifle that never loads, so the character stays missing and the lobby stays on its black loading screen.
-- This gives the menu character an M15 instead, for the Ztron guns and BO6 weapons. In game the character then loads
-- and the black clears by itself, but it shows no gun: the M15 does not appear. That was accepted as is.
-- It only changes the menu character: the class and the weapon in a match stay as they are.
-- If the black is still up after BLACK_WAIT_TICKS anyway, it is hidden until the game's own fade ends.
-- Logs to poi_reg.log as "k1 lobby:" lines. Delete this file to remove it.
do
    local FALLBACK_WEAPON = "sat_ar_eagle_mp"
    local WEAPON_WORLD_DEFAULT = 2
    local INTERVAL_MS, BLACK_WAIT_TICKS, MAX_LINES = 2000, 8, 200
    local CTRL = 0
    local HEX_MAP_PRIMARY, HEX_STREAM = "ae17ae124cc20134", "d88131525066eff4"
    local HEX_LOADED = "0a6309027523469f"
    local HEX_BLACKQUAD, HEX_SPINNER = "7d81717bc133e1fb", "3665e91744184986"
    local HEX_FRONTEND_CONDITION = "112586a3f4fb490e"
    local lines = 0
    local seen = {}

    local function log(message)
        local direct = rawget(_G, "DebugPrint")
        if type(direct) ~= "function" or lines >= MAX_LINES then return end
        lines = lines + 1
        pcall(direct, "k1 lobby: " .. string.sub(message, 1, 300))
    end

    -- The game's own way of making a hash constant, as in Kronos's menu script.
    local function uleb(n)
        local t = {}
        repeat
            local b = n % 128
            n = math.floor(n / 128)
            if n > 0 then b = b + 128 end
            t[#t + 1] = string.char(b)
        until n == 0
        return table.concat(t)
    end
    local hashes = {}
    local function H(hex)
        if hashes[hex] ~= nil then return hashes[hex] or nil end
        local ok, value = pcall(function()
            local b8 = {}
            for i = 8, 1, -1 do b8[#b8 + 1] = string.char(tonumber(hex:sub(i * 2 - 1, i * 2), 16)) end
            local kgc = string.char(4, 0) .. table.concat(b8)
            local bc = string.char(0x28, 0, 0, 0) .. string.char(0x4d, 0, 2, 0)
            local body = string.char(0, 0, 2, 0) .. uleb(1) .. uleb(0) .. uleb(2) .. bc .. kgc
            local chunk = string.char(27) .. "LJ" .. string.char(0x84) .. uleb(0x1a) .. uleb(#body) .. body .. string.char(0)
            return assert(load(chunk))()
        end)
        hashes[hex] = ok and value or false
        return ok and value or nil
    end

    local function text(value)
        if value == nil then return "nil" end
        local ok, s = pcall(tostring, value)
        return ok and s or type(value)
    end

    local function note(name, value)
        local now = text(value)
        if seen[name] == now then return end
        seen[name] = now
        log(name .. " = " .. now)
    end

    local function readField(object, key) return object[key] end
    local function field(object, key)
        local ok, value = pcall(readField, object, key)
        if ok then return value end
    end

    local function method(object, name)
        local fn = field(object, name)
        if type(fn) == "function" then return fn end
    end

    local function cantLoadInLobby(name)
        if type(name) ~= "string" then return false end
        return string.sub(name, 1, 4) == "t10_" or string.find(name, "ztron", 1, true) ~= nil
    end

    -- The M15 as the game itself would hand it to the character, so the game's own state check agrees with it.
    local gameMapping, fallbackName
    local function getFallback()
        if fallbackName then return fallbackName end
        local ok, mapped
        if gameMapping then ok, mapped = pcall(gameMapping, FALLBACK_WEAPON) end
        if ok and type(mapped) == "string" and not cantLoadInLobby(mapped) then
            fallbackName = mapped
        else
            fallbackName = FALLBACK_WEAPON
        end
        log("fallback weapon = " .. fallbackName .. ", game mapped it to " .. text(mapped))
        return fallbackName
    end

    local function makeMapWrapper(original)
        gameMapping = original
        local function choose(weapon, mapped, ...)
            if cantLoadInLobby(weapon) or cantLoadInLobby(mapped) then
                note("menu character weapon " .. text(weapon), "fallback, game gave " .. text(mapped))
                return getFallback()
            end
            return mapped, ...
        end
        return function(weapon, ...)
            return choose(weapon, original(weapon, ...))
        end
    end

    -- The game streams the weapon named in the loadout, so the M15 has to be asked for as well.
    -- Menu previews carry a menuName and are left alone.
    local function fallbackRequest(request)
        if type(request) ~= "table" or request.menuName ~= nil or type(request.models) ~= "table" then return nil end
        local streaming = rawget(_G, "STREAMING")
        local types = type(streaming) == "table" and streaming.ModelTypes
        local weaponWorld = type(types) == "table" and types.WeaponWorld or WEAPON_WORLD_DEFAULT
        if request.modelType ~= weaponWorld or not cantLoadInLobby(request.models[1]) then return nil end
        local extra = {}
        for key, value in pairs(request) do extra[key] = value end
        extra.models = { getFallback() }
        return extra
    end

    local function makeStreamWrapper(original)
        local function finish(controller, extra, ...)
            if extra then
                local ok, problem = pcall(original, controller, extra)
                if not ok then note("fallback stream error", problem) end
            end
            return ...
        end
        return function(controller, request, ...)
            local extra = fallbackRequest(request)
            return finish(controller, extra, original(controller, request, ...))
        end
    end

    local installed = {}
    local function wrapOnce(tableName, hex, make)
        local tbl, key = rawget(_G, tableName), H(hex)
        if type(tbl) ~= "table" or not key then return end
        local current = tbl[key]
        if type(current) ~= "function" or current == installed[hex] then return end
        local wrapper = make(current)
        tbl[key] = wrapper
        installed[hex] = wrapper
        log("wrapped " .. tableName .. "." .. hex)
    end

    local function childWithId(parent, part)
        local ok, child = pcall(parent.getFirstChild, parent)
        while ok and child do
            if string.find(text(field(child, "id")), part, 1, true) then return child end
            ok, child = pcall(child.getNextSibling, child)
        end
    end

    local function fadeElements(root)
        local fadeManager = childWithId(root, "FadeManager")
        local fade = fadeManager and childWithId(fadeManager, "e7979c6e156fcc97")
        if not fade then return {} end
        local found = {}
        for _, hex in ipairs({ HEX_BLACKQUAD, HEX_SPINNER }) do
            local key = H(hex)
            local element = key and field(fade, key)
            if element then found[#found + 1] = element end
        end
        return found
    end

    local function setFadeHidden(root, hide)
        for _, element in ipairs(fadeElements(root)) do
            local setAlpha, setVisible = method(element, "SetAlpha"), method(element, "SetVisible")
            if hide and setAlpha then pcall(setAlpha, element, 0) end
            if setVisible then pcall(setVisible, element, not hide) end
        end
    end

    local function isFrontend()
        local conditions, key = rawget(_G, "CONDITIONS"), H(HEX_FRONTEND_CONDITION)
        if not (conditions and key and conditions[key]) then return false end
        local ok, result = pcall(conditions[key])
        return ok and result == true
    end

    local function fadeValue()
        local ok, value = pcall(function()
            local source = LUI.DataSourceInGlobalModel.new("cg.frontendscene.opacity")
            return source:GetValue(CTRL)
        end)
        if ok and type(value) == "number" then return value end
    end

    local blackTicks, hidden = 0, false
    local function watchBlack(root)
        local value = fadeValue()
        note("black", value and value >= 0.5)
        if isFrontend() and value and value >= 0.5 then
            blackTicks = blackTicks + 1
            if blackTicks >= BLACK_WAIT_TICKS then
                if not hidden then log("black still up after " .. blackTicks * INTERVAL_MS / 1000 .. " s, hiding it") end
                hidden = true
                setFadeHidden(root, true)
            end
        else
            blackTicks = 0
            if hidden then
                hidden = false
                setFadeHidden(root, false)
                log("hidden black restored to the game's control")
            end
        end
    end

    local function logCharacter()
        local tbl, key = rawget(_G, "ClientCharacter"), H(HEX_LOADED)
        local fn = type(tbl) == "table" and key and tbl[key]
        if type(fn) ~= "function" then return end
        local ok, loaded = pcall(fn, 0, 0)
        if ok then note("character 0 loaded", loaded) end
    end

    local function look()
        wrapOnce("OPERATOR", HEX_MAP_PRIMARY, makeMapWrapper)
        wrapOnce("STREAMING", HEX_STREAM, makeStreamWrapper)
        local root = LUI and LUI.GetRoot and LUI.GetRoot()
        if not root then return end
        logCharacter()
        watchBlack(root)
    end

    local timer
    local function ensureTimer()
        if timer and timer:getParent() then return timer end
        local root = LUI and LUI.GetRoot and LUI.GetRoot()
        if not (root and LUI.UIElement) then return nil end
        timer = LUI.UIElement.new()
        root:addElement(timer)
        return timer
    end

    local function tick()
        local ok, problem = pcall(look)
        if not ok then note("error", problem) end
        local armed, reason = pcall(function() ensureTimer():Wait(INTERVAL_MS).onComplete = tick end)
        if not armed then log("timer error: " .. text(reason)) end
    end

    log("started")
    tick()
end
