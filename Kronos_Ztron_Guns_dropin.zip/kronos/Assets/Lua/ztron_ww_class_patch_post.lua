-- Ztron wonder weapons class patch (v4).
--
-- Goal: the Zombies create-a-class WONDER WEAPON list should offer the two
-- weapons that ship only with the Ztron map, exactly like the shipped wonder
-- weapons:
--
--     sat_lm_ztronjetgun  (Thrustodyne M23 / jet gun)   loot id 98083
--     sat_ar_ztrondg2     (Wunderwaffe DG-2)            loot id 100641
--
-- Why they were missing: the list is built from the item/loot table. Shipped
-- wonder weapons are weapon data whose classdata is `sat_wonder_weapon`,
-- menuclass `weapon_wonder`, and whose loot id points at their item. The two
-- Ztron weapons ship as a plain LMG and AR inside the map zone: classdata
-- sat_lm / sat_ar, no loot id at all (the camo patch lists both with loot id
-- 0), so nothing can ever file them under the wonder weapon category.
--
-- This patch therefore reclassifies the weapon data and gives it the matching
-- loot id, through every route the frontend uses to read weapon data:
--
--     WEAPON.getweapondata / WEAPON.getweapondef   (native weapon table)
--     Engine.GetScriptBundle("weapondata:<ref>")   (script bundle route)
--
-- The exact value shapes (string vs XHash) are learned from a shipped wonder
-- weapon (sat_ww_raygun) at install time, so comparisons inside the native
-- lists see the same values they see for the real wonder weapons. Nothing is
-- invented: writes are read back to confirm they took effect, and the patch
-- reports honestly when a value would not stick.
--
-- v4 notes
--   * The game asks for a weapon bundle by hashed name, so matching the requested
--     name as a string almost never fired. Bundles are now matched by their own
--     ref field, as Kronos does, and handed back through a proxy instead of being
--     written to.
--   * Loot ids go into Kronos's table (LUIFPSCounter.lua), so that saving and
--     loading a pick works as it does for its BO6 guns.
--   * Logs through the global DebugPrint with a "k1 " prefix, which reaches poi_reg.log.
--
-- v3 notes
--   * v1 matched refs with tostring(ref); the frontend passes XHash values, so
--     it never matched. Refs are matched by string, by CLUA.PushXHash and by
--     tostring() marker.
--   * v2 set a hard-coded string for classdata, which is wrong when the game
--     stores an XHash there. Values now come from a real wonder weapon.
--   * v2 replaced userdata weapon data with a Lua proxy table. That is unsafe
--     if native code receives it, so now userdata is mutated in place and only
--     handed back if the write verifies. Otherwise the original is returned.
--   * no guessed mode gate: the patch installs unconditionally, logs whether
--     CONDITIONS.IsZM() says zombies, and lets the read-back decide.

local GLOBAL_NAME = "ZtronWonderClassPatch"
local VERSION = 4

local prior = rawget(_G, GLOBAL_NAME)
if type(prior) == "table" and type(prior.Restore) == "function" then
    pcall(prior.Restore)
end

-- canonical ref -> loot id from the shipped BO7 item index
local ZTRON_WEAPONS = {
    ["sat_lm_ztronjetgun"] = 98083,
    ["sat_ar_ztrondg2"] = 100641,
    -- test: Apothicon Servant from examples/Apothicon_Servant_V1 (no item of its own)
    ["sat_ww_servant_zm"] = 0,
}

-- the same weapon ships under several refs: an _mp asset name, the zombies
-- variant names the shared zm zone knows, and the Pack-a-Punch variants that
-- the map's zone defines. All of them are the same two wonder weapons.
local ZTRON_ALIASES = {
    ["sat_lm_ztronjetgun_mp"] = "sat_lm_ztronjetgun",
    ["sat_lm_ztronjetgun_pack"] = "sat_lm_ztronjetgun",
    ["sat_ar_ztrondg2_mp"] = "sat_ar_ztrondg2",
    ["sat_ar_ztrondg2_pack"] = "sat_ar_ztrondg2",
    ["sat_zm_ztronjetgun"] = "sat_lm_ztronjetgun",
    ["sat_zm_ztronjetgun_pack"] = "sat_lm_ztronjetgun",
    ["sat_zm_ar_ztrondg2"] = "sat_ar_ztrondg2",
    ["sat_zm_ar_ztrondg2_pack"] = "sat_ar_ztrondg2",
}

local api = {
    version = VERSION,
    installed = false,
    matched = 0,
    mutated = 0,
    failed = 0,
    verified = {},
    seen = {},
    Restore = function() return true end,
}

-- ------------------------------------------------------------------ helpers

local function clua()
    return rawget(_G, "CLUA")
end

local function push(name)
    local c = clua()
    if type(c) == "table" and type(c.PushXHash) == "function" then
        local ok, key = pcall(c.PushXHash, name)
        if ok and key ~= nil then return key end
    end
    return name
end

local function resolve(object, name)
    if type(object) ~= "table" then return nil end
    local hash_key = push(name)
    local fn = rawget(object, hash_key)
    if type(fn) == "function" then return hash_key, fn end
    if hash_key ~= name then
        fn = rawget(object, name)
        if type(fn) == "function" then return name, fn end
    end
    return nil
end

-- Lines starting "k1 " reach poi_reg.log. io.open does nothing in the game's Lua.
local log_channel = "debugprint"
local function log(line)
    local direct = rawget(_G, "DebugPrint")
    if type(direct) ~= "function" then return false end
    return (pcall(direct, "k1 ztronww: " .. line))
end

-- ref -> canonical name, built once for both string and XHash keys
local STRING_NAMES = {}
local HASH_NAMES = {}
for alias, canonical in pairs(ZTRON_ALIASES) do
    STRING_NAMES[alias] = canonical
end
for canonical in pairs(ZTRON_WEAPONS) do
    STRING_NAMES[canonical] = canonical
end
for alias, canonical in pairs(ZTRON_ALIASES) do
    local key = push(alias)
    if key ~= nil then HASH_NAMES[key] = canonical end
end
for canonical in pairs(ZTRON_WEAPONS) do
    local key = push(canonical)
    if key ~= nil then HASH_NAMES[key] = canonical end
end

local function canonical_ref(ref)
    if ref == nil then return nil end
    if type(ref) == "string" then
        local bare = string.lower((string.gsub(ref, "^@", "")))
        return STRING_NAMES[bare]
    end
    local by_hash = HASH_NAMES[ref]
    if by_hash ~= nil then return by_hash end
    local ok, text = pcall(tostring, ref)
    if ok and type(text) == "string" then
        text = string.lower(text)
        if string.find(text, "ztronjetgun", 1, true) then return "sat_lm_ztronjetgun" end
        if string.find(text, "ztrondg2", 1, true) then return "sat_ar_ztrondg2" end
    end
    return nil
end

-- keys the menu reads. PushXHash turns each name into the table key the game
-- uses internally; the plain name is the fallback when CLUA is not there.
-- Resolved lazily, so a late CLUA still yields the right keys.
local KEY = {}
local function key_of(name)
    local key = KEY[name]
    if key == nil then
        key = push(name)
        KEY[name] = key
    end
    return key
end

-- value shapes, learned from sat_ww_raygun
local template = { classdata = nil, menuclass = nil, lootid = nil, sample = false }

local function wonder_classdata()
    if template.classdata ~= nil then return template.classdata end
    return push("sat_wonder_weapon")
end

local function wonder_menuclass()
    if template.menuclass ~= nil then return template.menuclass end
    return push("weapon_wonder")
end

-- ------------------------------------------------------------------ access

-- read a member of a table *or* engine userdata, by hash key then by name
local function field(data, name)
    local key = key_of(name)
    local ok, value = pcall(function() return data[key] end)
    if ok and value ~= nil then return value end
    if key ~= nil and key ~= name then
        ok, value = pcall(function() return data[name] end)
        if ok and value ~= nil then return value end
    end
    return nil
end

-- write a member and read it back; returns true only when the read matches
local function set_field(data, name, value)
    local key = key_of(name)
    local wrote = false
    if key ~= nil then
        if pcall(function() data[key] = value end) then wrote = true end
    end
    if key ~= name then
        if pcall(function() data[name] = value end) then wrote = true end
    end
    if not wrote then return false end
    local readback = field(data, name)
    return readback == value, readback
end

-- ------------------------------------------------------------------ mutation

local function reclassify(data, canonical)
    local loot = ZTRON_WEAPONS[canonical]
    local before_class = field(data, "classdata")
    local before_menu = field(data, "menuclass")
    local before_loot = field(data, "lootid")

    local class_ok, class_read = set_field(data, "classdata", wonder_classdata())
    local menu_ok, menu_read = set_field(data, "menuclass", wonder_menuclass())
    local loot_ok = set_field(data, "lootid", loot)

    -- the camo/gunsmith route in bo7_zm_wonder_weapons_camo_gunsmith_post.lua
    -- needs these exactly like the shipped wonder weapons, so write them even
    -- when the weapon does not carry the member yet
    set_field(data, "canusecosmetic", true)
    set_field(data, "isgunsmithdisabled", false)
    -- map-only weapons ship hideinui=true, so every create-a-class tab skips them
    local before_hide = field(data, "hideinui")
    local _, hide_read = set_field(data, "hideinui", false)
    if before_hide ~= false then
        log(string.format("hideinui %s: %s -> %s", canonical, tostring(before_hide), tostring(hide_read)))
    end

    return {
        ok = class_ok and menu_ok and loot_ok,
        before_class = before_class,
        before_menu = before_menu,
        before_loot = before_loot,
        class_read = class_read,
        menu_read = menu_read,
    }
end

local function describe(report, canonical, kind)
    local loot = ZTRON_WEAPONS[canonical]
    local verdict = report.ok and "ok" or "PARTIAL"
    log(string.format(
        "reclassified %s (%s): classdata %s -> %s, menuclass %s -> %s, lootid %s -> %d [%s]",
        canonical, kind,
        tostring(report.before_class), tostring(report.class_read),
        tostring(report.before_menu), tostring(report.menu_read),
        tostring(report.before_loot), loot, verdict))
end

local function classify(data, ref)
    if type(data) ~= "table" and type(data) ~= "userdata" then return data end
    local canonical = canonical_ref(ref)
    if canonical == nil then
        canonical = canonical_ref(field(data, "ref"))
    end
    if canonical == nil then return data end

    api.matched = api.matched + 1
    local first = api.seen[canonical] == nil
    api.seen[canonical] = (api.seen[canonical] or 0) + 1

    local report = reclassify(data, canonical)
    if first then
        if report.ok then
            api.mutated = api.mutated + 1
            api.verified[canonical] = true
        else
            api.failed = api.failed + 1
            api.verified[canonical] = false
            log(string.format(
                "could not fully reclassify %s (%s): the game ignores the write, a zone-side change is required",
                canonical, type(data)))
        end
        describe(report, canonical, type(data))
    end
    return data
end

-- ------------------------------------------------------------------ hooks

local function wrap_method(object, name, make_wrapper)
    if type(object) ~= "table" then return nil end
    local key = push(name)
    local original = rawget(object, key)
    if type(original) ~= "function" then
        key = name
        original = rawget(object, name)
    end
    if type(original) ~= "function" then return nil end
    local wrapper = make_wrapper(original)
    rawset(object, key, wrapper)
    return { object = object, key = key, original = original, wrapper = wrapper }
end

local hooks = {}
local function add_hook(record)
    if record ~= nil then hooks[#hooks + 1] = record end
end

local weapon = rawget(_G, "WEAPON")
local engine = rawget(_G, "Engine")

local bundle_native = nil
local bundle_data
bundle_data = function(ref)
    if type(bundle_native) ~= "function" or ref == nil then return nil end
    local ok, result = pcall(bundle_native, "weapondata:" .. tostring(ref))
    if ok then return result end
    return nil
end

-- Capture the native bundle getter before it is wrapped, then learn the exact
-- value shapes from a shipped wonder weapon, so the classes written below
-- compare equal to the real ones.
do
    local _, bundle_getter = resolve(engine, "getscriptbundle")
    if bundle_getter ~= nil then bundle_native = bundle_getter end

    local sample = bundle_data("sat_ww_raygun")
    if type(sample) ~= "table" and type(sample) ~= "userdata" then
        local _, getter = resolve(weapon, "getweapondata")
        if getter ~= nil then
            local ok, result = pcall(getter, "sat_ww_raygun")
            if ok then sample = result end
        end
    end
    if type(sample) == "table" or type(sample) == "userdata" then
        template.classdata = field(sample, "classdata")
        template.menuclass = field(sample, "menuclass")
        template.lootid = field(sample, "lootid")
        template.sample = true
    end
end

-- Every weapon-data ref the menu asks for is logged once, so a session report
-- shows whether the frontend goes through these routes at all.
local queried = {}
local query_count = 0
local function note_query(ref)
    local text = tostring(ref)
    if queried[text] then return end
    queried[text] = true
    query_count = query_count + 1
    if query_count <= 40 then log("query " .. text) end
    if query_count == 40 then log("further query logs suppressed") end
end

for _, name in ipairs({ "getweapondata", "getweapondef" }) do
    add_hook(wrap_method(weapon, name, function(native)
        return function(ref, ...)
            local result = native(ref, ...)
            note_query(ref)
            if result == nil then
                -- the bundle can still have data the native table lacks
                return classify(bundle_data(ref), ref)
            end
            return classify(result, ref)
        end
    end))
end

-- engine keys are FNV-1a of the lowercase name (Kronos hooks H("f06093d047200548") = getscriptbundle)

-- BO6 (t10_) guns in the zombies create-a-class list. Kronos adds these for multiplayer only
-- (ui/LUIFPSCounter.lua clears its list when in zombies); this re-adds them the same way.
-- Menu only: equipping one in a zombies match is not handled yet.
local function uleb(n)
    local t = {}
    repeat
        local b = n % 128
        n = math.floor(n / 128)
        if n > 0 then b = b + 128 end
        t[#t + 1] = string.char(b)
    until n == 0
    return table.concat(t)
end
-- Kronos's H(): builds the engine's 64-bit hash constant from hex via a one-op LuaJIT chunk
local function xhash(hex, kind)
    local h = string.rep("0", 16 - #hex) .. hex
    local b8 = {}
    for i = 8, 1, -1 do b8[#b8 + 1] = string.char(tonumber(h:sub(i * 2 - 1, i * 2), 16)) end
    local body = string.char(0, 0, 2, 0) .. uleb(1) .. uleb(0) .. uleb(2)
        .. string.char(0x28, 0, 0, 0, 0x4d, 0, 2, 0) .. string.char(4, kind or 0) .. table.concat(b8)
    local chunk = string.char(27) .. "LJ" .. string.char(0x84) .. uleb(0x1a) .. uleb(#body) .. body .. string.char(0)
    local ok, f = pcall(load, chunk)
    if not ok or type(f) ~= "function" then return nil end
    local ok2, v = pcall(f)
    return ok2 and v or nil
end
local BO6 = { "t10_ar_p01_coslo723", "t10_ar_p02_aking74", "t10_ar_p04_clove", "t10_ar_p05_fable",
    "t10_ar_p05_rmary2", "t10_ar_p06_asvalor", "t10_ar_p22_able18", "t10_ar_p23_love85", "t10_ar_p28_saug",
    "t10_ar_p34_tbaker", "t10_ar_p45_kent", "t10_ar_p47_gilroy", "t10_ar_p49_fresno", "t10_ar_p54_aspen",
    "t10_ar_p56_milan", "t10_dm_p01_sroger25", "t10_dm_p02_aeasy", "t10_dm_p03_sgeorge550", "t10_dm_p05_falove",
    "t10_dm_p09_svalor", "t10_dm_p50_erie", "t10_la_p17_pable3", "t10_la_p18_stisaac", "t10_lm_p01_aroger10",
    "t10_lm_p02_puncle21", "t10_lm_p07_ksugar58", "t10_lm_p33_uxray", "t10_lm_p53_mesa", "t10_me_p15_knife",
    "t10_me_p16_bat", "t10_me_p30_cleaver", "t10_me_p31_drill", "t10_me_p36_skateboard", "t10_me_p37_katanas",
    "t10_me_p38_sais", "t10_me_p39_nunchaku", "t10_me_p39_nunchucku", "t10_me_p40_bostaff", "t10_me_p48_keene",
    "t10_me_p51_pickaxe", "t10_me_p55_bgloves", "t10_me_p59_chainsaw", "t10_me_p59_csaw", "t10_pi_p12_paris30",
    "t10_pi_p13_usugar9", "t10_pi_p14_mable", "t10_pi_p14_stiger", "t10_pi_p14_striger", "t10_pi_p42_pyork",
    "t10_sh_p10_moslo500", "t10_sh_p11_olove", "t10_sh_p25_uncle12", "t10_sh_p27_jhavana", "t10_sl_p29_goslo",
    "t10_sl_p35_blauncher", "t10_sl_p44_napa", "t10_sl_p58_artifact", "t10_sl_p58_wand", "t10_sm_p02_geasy9",
    "t10_sm_p02_s4blk", "t10_sm_p03_safox", "t10_sm_p04_chuck9", "t10_sm_p06_sroger3", "t10_sm_p12_roger31",
    "t10_sm_p21_pparis90", "t10_sm_p28_saug", "t10_sm_p41_perth", "t10_sm_p43_schuck", "t10_sm_p52_lisbon",
    "t10_sm_p57_mpug40", "t10_sn_p01_sroger25", "t10_sn_p08_ultiger", "t10_sn_p09_droger", "t10_sn_p24_love96",
    "t10_sn_p26_mary82", "t10_sn_p46_hugo" }
local function add_bo6(copy)
    local k_data, k_bo6 = xhash("86d696ad252f1cb1"), xhash("1a8f1706b0f16d97")
    local prefix = xhash("31705bf9ed477170", 3)  -- Kronos's weapon-bundle name prefix
    if k_data == nil or k_bo6 == nil or prefix == nil or bundle_native == nil then
        log("bo6: hash keys unavailable, skipped")
        return 0
    end
    local have = {}
    for _, e in ipairs(copy) do
        local ok, wd = pcall(function() return e[k_data] end)
        if ok and wd ~= nil then have[tostring(wd)] = true end
    end
    _G.__kronosBo6Loot = _G.__kronosBo6Loot or {}  -- Kronos saves/loads BO6 picks through this
    local loot = _G.__kronosBo6Loot
    local n = 0
    for _, ref in ipairs(BO6) do
        local ok, wb = false, nil
        if not have[ref] then ok, wb = pcall(bundle_native, prefix .. ref) end
        if ok and type(wb) == "table" then
            copy[#copy + 1] = { [k_data] = ref, [k_bo6] = true }
            have[ref] = true
            local id = field(wb, "lootid")
            if id ~= nil and type(loot) == "table" then loot[tostring(id)] = ref end
            n = n + 1
        end
    end
    return n
end

-- Bundle fields, by the engine's key for each name. A shipped wonder weapon supplies the class values.
local K = {
    ref = xhash("89e9c01960f4c582"), lootid = xhash("8028887f70bf5eba"), hideinui = xhash("8aed63dfe5400760"),
    classdata = xhash("100edb64644d9b07"), menuclass = xhash("556143152458180a"), displayorder = xhash("e4fb3c98aeeab347"),
    canusecosmetic = xhash("b0c042260524de03"), isgunsmithdisabled = xhash("04fdaecd20551368"),
    iscustomizationdisabled = xhash("54348964940172be"),
}
local WEAPON_BUNDLE_PREFIX = xhash("31705bf9ed477170", 3)
local DISPLAY_AFTER_RAYGUN = { sat_lm_ztronjetgun = 20, sat_ar_ztrondg2 = 21 }
local wonder_sample

local function wonder_values()
    if wonder_sample then return wonder_sample end
    local ok, sample = false, nil
    if WEAPON_BUNDLE_PREFIX ~= nil then ok, sample = pcall(bundle_native, WEAPON_BUNDLE_PREFIX .. "sat_ww_raygun") end
    if not ok or type(sample) ~= "table" then sample = bundle_data("sat_ww_raygun") end
    if type(sample) ~= "table" then return nil end
    wonder_sample = { classdata = sample[K.classdata], menuclass = sample[K.menuclass], displayorder = tonumber(sample[K.displayorder]) or 0 }
    log(string.format("raygun: classdata=%s menuclass=%s order=%s hideinui=%s lootid=%s cosmetic=%s", tostring(wonder_sample.classdata),
        tostring(wonder_sample.menuclass), tostring(sample[K.displayorder]), tostring(sample[K.hideinui]), tostring(sample[K.lootid]), tostring(sample[K.canusecosmetic])))
    return wonder_sample
end

local logged_bundle = {}
local function wonder_proxy(bundle, canonical)
    local wonder = wonder_values()
    local own_loot = tonumber(bundle[K.lootid]) or 0
    if not logged_bundle[canonical] then
        logged_bundle[canonical] = true
        log(string.format("bundle %s: classdata=%s menuclass=%s order=%s hideinui=%s lootid=%s cosmetic=%s gunsmithdisabled=%s", canonical,
            tostring(bundle[K.classdata]), tostring(bundle[K.menuclass]), tostring(bundle[K.displayorder]), tostring(bundle[K.hideinui]),
            tostring(bundle[K.lootid]), tostring(bundle[K.canusecosmetic]), tostring(bundle[K.isgunsmithdisabled])))
    end
    local over = {
        [K.hideinui] = false,
        [K.canusecosmetic] = true,
        [K.isgunsmithdisabled] = false,
        [K.iscustomizationdisabled] = false,
        [K.lootid] = own_loot > 0 and bundle[K.lootid] or ZTRON_WEAPONS[canonical],
    }
    if wonder then
        over[K.classdata] = wonder.classdata
        over[K.menuclass] = wonder.menuclass
        over[K.displayorder] = wonder.displayorder + (DISPLAY_AFTER_RAYGUN[canonical] or 22)
    end
    return setmetatable(over, { __index = bundle })
end

add_hook(wrap_method(engine, "getscriptbundle", function(native)
    bundle_native = native
    local lists = setmetatable({}, { __mode = "k" })
    return function(name, ...)
        local result = native(name, ...)
        if type(result) == "table" and K.ref ~= nil then
            local canonical = STRING_NAMES[tostring(result[K.ref])]
            if canonical == nil and type(name) == "string" and string.sub(name, 1, 11) == "weapondata:" then
                canonical = canonical_ref(string.sub(name, 12))
            end
            -- Item entries and other bundles can have the same ref; only weapon data has a class.
            if canonical ~= nil and result[K.classdata] ~= nil then return wonder_proxy(result, canonical) end
        end
        -- the create-a-class grid is one bundle list of {weapondata = ref}; map-only
        -- weapons are never in it, so append them (same shape Kronos uses for its bo6 adds)
        local list = type(result) == "table" and field(result, "weapons") or nil
        if type(list) == "table" and type(list[1]) == "table" and field(list[1], "weapondata") ~= nil then
            local copy = lists[list]
            if copy == nil then
                local have, added = {}, {}
                copy = {}
                for i, e in ipairs(list) do
                    copy[i] = e
                    local c = canonical_ref(field(e, "weapondata"))
                    if c then
                        have[c] = true
                        log(string.format("list entry %d: weapondata=%s -> %s", i, tostring(field(e, "weapondata")), c))
                    end
                end
                for canonical in pairs(ZTRON_WEAPONS) do
                    if not have[canonical] then
                        copy[#copy + 1] = { [key_of("weapondata")] = canonical }
                        added[#added + 1] = canonical
                    end
                end
                local bo6 = add_bo6(copy)
                if bo6 > 0 then added[#added + 1] = bo6 .. " bo6 guns" end
                -- diagnostic: the menu converts the list through a method on it; report
                -- whether our weapons survive that conversion
                local reported = false
                setmetatable(copy, { __index = function(_, key)
                    local v = list[key]
                    if type(v) ~= "function" then return v end
                    return function(_, ...)
                        local r = v(list, ...)
                        if not reported and type(r) == "table" then
                            reported = true
                            local parts = {}
                            for _, ref in ipairs({ "sat_ww_raygun", "sat_lm_ztronjetgun", "sat_ar_ztrondg2", "sat_ww_servant_zm" }) do
                                local ok, item = pcall(function() return r[ref] end)
                                parts[#parts + 1] = ref .. "=" .. (ok and type(item) or "err")
                            end
                            log("converted list: " .. table.concat(parts, " "))
                        end
                        return r
                    end
                end })
                lists[list] = copy
                log(string.format("weapon list %s: %d entries, added %s",
                    tostring(name), #list, table.concat(added, " ")))
            end
            return setmetatable({ [key_of("weapons")] = copy }, { __index = result })
        end
        return result
    end
end))

-- ------------------------------------------------------------------ install

local function restore()
    for _, record in ipairs(hooks) do
        if rawget(record.object, record.key) == record.wrapper then
            rawset(record.object, record.key, record.original)
        end
    end
    api.installed = false
    return true
end

api.Restore = restore
api.classify = classify
api.reclassify = reclassify
api.template = template

if #hooks == 0 then
    log("install failed: neither WEAPON.getweapondata nor Engine.GetScriptBundle is reachable")
    rawset(_G, GLOBAL_NAME, api)
    return
end

-- report the mode we are in (diagnostic only; the patch does not gate on it,
-- because the create-a-class screen is a frontend screen, not a match)
local conditions = rawget(_G, "CONDITIONS")
local _, zm_fn = resolve(conditions, "IsZM")
local zm_state = "unknown"
if zm_fn ~= nil then
    local ok, value = pcall(zm_fn)
    if ok then zm_state = tostring(value) end
end

api.installed = true
rawset(_G, GLOBAL_NAME, api)

log(string.format(
    "installed v%d: %d route(s), zombies=%s, log via %s",
    VERSION, #hooks, zm_state, log_channel))
log(string.format(
    "wonder template: classdata=%s (%s), menuclass=%s (%s), lootid=%s (sample=%s)",
    tostring(template.classdata), type(template.classdata),
    tostring(template.menuclass), type(template.menuclass),
    tostring(template.lootid), tostring(template.sample)))

-- Probe both weapons once now: this reports immediately whether their data is
-- reachable from the frontend at all.
for canonical in pairs(ZTRON_WEAPONS) do
    local data = nil
    local _, getter = resolve(weapon, "getweapondata")
    if getter ~= nil then
        local ok, result = pcall(getter, canonical)
        if ok and result ~= nil then data = result end
    end
    if data == nil then data = bundle_data(canonical) end
    if data == nil or type(data) ~= "table" and type(data) ~= "userdata" then
        log("probe " .. canonical .. ": no data reachable from the frontend")
    else
        local type_name = type(data)
        classify(data, canonical)
        log(string.format("probe %s: %s, classdata=%s, menuclass=%s, lootid=%s",
            canonical, type_name,
            tostring(field(data, "classdata")),
            tostring(field(data, "menuclass")),
            tostring(field(data, "lootid"))))
    end
end

-- Kronos installs its loot wrappers from a repeating check that re-wraps whenever the function is not its own, so ours
-- goes on after its and takes its global, which stops the re-wrap from stacking.
local function wire_loot()
    local loot = rawget(_G, "LOOT")
    if type(loot) ~= "table" then return false end
    _G.__kronosBo6Loot = _G.__kronosBo6Loot or {}
    for canonical, id in pairs(ZTRON_WEAPONS) do
        if id ~= 0 then _G.__kronosBo6Loot[tostring(id)] = canonical end
    end
    local k_id = xhash("c36548909cff94cd")
    local current = k_id ~= nil and loot[k_id] or nil
    if type(current) ~= "function" or current ~= rawget(_G, "__kronosBo6LootId") or rawget(_G, "__ztronWwLootId") == current then
        return rawget(_G, "__ztronWwLootId") == current and current ~= nil
    end
    for _, ref in ipairs({ "sat_ww_raygun", "sat_lm_ztronjetgun", "sat_ar_ztrondg2" }) do
        local ok, id = pcall(current, ref)
        log(string.format("loot id the game has for %s: %s", ref, ok and tostring(id) or "error"))
    end
    local wrapped = function(ref, ...)
        local id = current(ref, ...)
        if id ~= nil and id ~= 0 then return id end
        local canonical = type(ref) == "string" and STRING_NAMES[ref] or nil
        if canonical ~= nil and ZTRON_WEAPONS[canonical] ~= 0 then return ZTRON_WEAPONS[canonical] end
        return id
    end
    loot[k_id] = wrapped
    rawset(_G, "__kronosBo6LootId", wrapped)
    rawset(_G, "__ztronWwLootId", wrapped)
    log("loot wired")
    return true
end

local function loot_tick()
    local installed = rawget(_G, GLOBAL_NAME)
    if installed ~= api then return end
    pcall(wire_loot)
    local root = rawget(_G, "LUI") and LUI.GetRoot and LUI.GetRoot()
    if root then pcall(function() root:Wait(2000).onComplete = loot_tick end) end
end
loot_tick()

log("ready: open create-a-class and look for both weapons in the wonder weapon list")
