-- zm_mutant_injection_menu_post.lua
-- Menu side of zm_mutant_injection.gsc (custom_scripts). Goes in kronos\Assets\Lua.
--   * Crafting table: a Mutant Injection tile on the Support tab. Buying it sends "craft_purchase" with MI_CRAFT_INDEX,
--     which the GSC handles. The tile copies the tab's last tile, as zm_void_claw_menu_post.lua does for the Void Claw.
--   * Pick-up card: legendary, matching the drop's glow. The item's own entry has no rarity.

pcall(function()
local old=rawget(_G,"ZMMutantInjectionMenu")
if old then old.enabled=false end
local S={enabled=true}
rawset(_G,"ZMMutantInjectionMenu",S)

local MI_REF="zm_minj"
local MI_CRAFT_INDEX=103 -- must match level.zm_minj.craft_index in the GSC
local MI_CRAFT_COST=2500 -- must match level.zm_minj.craft_cost in the GSC
local MI_RARITY=4        -- must match level.zm_minj.rarity in the GSC
local MI_ICON="sat_ui_icon_zm_support_injector_purple"
-- Text keys as the game's own killstreak bundle stores them (sat_killstreaks/mutant_injection and _desc, global_shared_mp).
local MI_NAME_HASH="7f5736418ddbe75a"
local MI_DESC_HASH="7d5aed4f2fd357ea"
local TEXT_HASH_KIND=3 -- what Kronos passes to Engine.Localize; a tile's own value decides when it has one
-- Lines starting "k1 " reach poi_reg.log. io.open does nothing in the game's Lua.
local function log(line)
 local f=rawget(_G,"DebugPrint")
 if type(f)=="function" then pcall(f,"k1 minj: "..tostring(line)) end
end

local CLUA=rawget(_G,"CLUA")
local keyCache={}
local function hx(name)
 if not (CLUA and type(CLUA.PushXHash)=="function") then return nil end
 if keyCache[name]==nil then
  local ok,v=pcall(CLUA.PushXHash,name)
  keyCache[name]=ok and v or false
 end
 return keyCache[name] or nil
end

local function keys(name,hash)
 local k={name}
 local v=hx(name); if v~=nil then k[#k+1]=v end
 if hash then v=hx(hash); if v~=nil then k[#k+1]=v end end
 return k
end

local function get(tbl,name)
 if tbl==nil then return nil end
 for _,key in ipairs(keys(name)) do
  local ok,v=pcall(function() return tbl[key] end)
  if ok and v~=nil then return v end
 end
end

-- Each function is hooked only once per table and name, so this file never wraps its own hooks.
local hookedOnce=setmetatable({},{__mode="k"})
local function once(tbl,key)
 local d=hookedOnce[tbl]
 if not d then d={}; hookedOnce[tbl]=d end
 if d[key] then return false end
 d[key]=true
 return true
end

local function sfx(k) return tostring(k):sub(-8):lower() end
local function keyOf(t,suffix)
 if type(t)~="table" then return nil end
 for k,_ in pairs(t) do if sfx(k)==suffix then return k end end
end
local function fieldOf(t,suffix)
 local k=keyOf(t,suffix)
 if k~=nil then return t[k] end
end

-- ------------------------------------------------ crafting table tile ----
local miTiles=setmetatable({},{__mode="k"})
local miLists=setmetatable({},{__mode="k"})
local tabsSeen={}

local function noteTab(name)
 if tabsSeen[name] then return end
 tabsSeen[name]=true
 log("tab "..name)
end

-- Kronos's H(): builds one of the engine's hash constants through a one-instruction LuaJIT chunk. CLUA.PushXHash makes a
-- different kind of hash, which the UI rejects for text: setText raised an error that broke the whole row.
local function uleb(n)
 local t={}
 repeat
  local b=n%128
  n=math.floor(n/128)
  if n>0 then b=b+128 end
  t[#t+1]=string.char(b)
 until n==0
 return table.concat(t)
end
local function xhash(hex,kind)
 local b8={}
 for i=8,1,-1 do b8[#b8+1]=string.char(tonumber(hex:sub(i*2-1,i*2),16)) end
 local body=string.char(0,0,2,0)..uleb(1)..uleb(0)..uleb(2)
  ..string.char(0x28,0,0,0,0x4d,0,2,0)..string.char(4,kind)..table.concat(b8)
 local chunk=string.char(27).."LJ"..string.char(0x84)..uleb(0x1a)..uleb(#body)..body..string.char(0)
 local ok,f=pcall(load,chunk)
 if not ok or type(f)~="function" then return nil end
 local ok2,v=pcall(f)
 return ok2 and v or nil
end

-- Same kind of hash as the value it replaces, which tostring shows as "xhash: #x<kind><16 digits>".
local function textLike(current,hex)
 local kind=tonumber(tostring(current):match("#x(%x)%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$") or "",16) or TEXT_HASH_KIND
 return xhash(hex,kind) or current
end

local tileLogged=false
local function makeTile(base,idx)
 local tile={}
 for k,v in pairs(base) do tile[k]=v end
 if not tileLogged then
  tileLogged=true
  local function desc(v) return type(v).." "..tostring(v) end
  log("copied tile: name "..desc(fieldOf(tile,"f695c8f6")).." desc "..desc(fieldOf(tile,"c8397929")).." icon "..desc(fieldOf(tile,"8528489a")).." cost "..desc(fieldOf(tile,"197c9f78")).." index "..desc(fieldOf(tile,"40657d07")))
 end
 local set=function(suffix,v)
  local k=keyOf(tile,suffix)
  if k~=nil then tile[k]=v end
 end
 set("197c9f78",MI_CRAFT_COST)  -- cost
 set("40657d07",MI_CRAFT_INDEX) -- number sent on purchase
 set("fd95bc39",idx)            -- position on the tab
 set("8528489a",MI_ICON)        -- icon
 set("d0208187",MI_REF)         -- item
 set("f695c8f6",textLike(fieldOf(tile,"f695c8f6"),MI_NAME_HASH)) -- name
 set("c8397929",textLike(fieldOf(tile,"c8397929"),MI_DESC_HASH)) -- description
 miTiles[tile]=true
 return tile
end

local function isTab(t)
 local v=fieldOf(t,"b1224e91")
 if type(v)~="string" then return false end
 noteTab(v)
 v=v:lower()
 return v:find("support",1,true)~=nil or v:find("streak",1,true)~=nil
end

local function extendList(list)
 if miLists[list]~=nil then return end
 local n=#list
 if n>0 then
  list[n+1]=list[n]
  miLists[list]=n+1
 else
  miLists[list]=false
 end
end

local function extendTab(tab)
 if type(tab)~="table" or not isTab(tab) then return end
 local list=fieldOf(tab,"4f412c6f")
 if type(list)=="table" then extendList(list) end
end

local scannedTabs=setmetatable({},{__mode="k"})
local function preExtend(tab)
 if scannedTabs[tab] then return end
 scannedTabs[tab]=true
 local seen={}
 local budget=600
 local function walk(t,depth)
  if budget<=0 or depth>4 or type(t)~="table" or seen[t] then return end
  seen[t]=true
  budget=budget-1
  extendTab(t)
  for _,v in pairs(t) do
   if type(v)=="table" then walk(v,depth+1) end
  end
 end
 walk(tab,0)
end

-- The tab's list holds items the menu hides, so a row number is not a position in the list and the new row cannot be found
-- by position. Extending the list copies its last entry, so the new row is the one that repeats the row before it.
local function sameItem(a,b)
 local x,y=fieldOf(a,"d0208187"),fieldOf(b,"d0208187")
 if x==nil then x,y=fieldOf(a,"f695c8f6"),fieldOf(b,"f695c8f6") end
 return x~=nil and x==y
end

local builderLogs=0
local function builderWrap(orig)
 return function(tab,idx,...)
  if S.enabled and type(tab)=="table" then pcall(preExtend,tab) end
  local tile=orig(tab,idx,...)
  if not S.enabled or type(tab)~="table" or type(tile)~="table" or not isTab(tab) then return tile end
  local row=tonumber(idx)
  if builderLogs<40 then
   builderLogs=builderLogs+1
   log("row "..tostring(idx).." item "..tostring(fieldOf(tile,"d0208187")).." list "..tostring(#(fieldOf(tab,"4f412c6f") or {})))
  end
  if not row or row<1 then return tile end
  local ok,prev=pcall(orig,tab,row-1,...)
  if ok and type(prev)=="table" and sameItem(tile,prev) then
   local ok2,mine=pcall(makeTile,tile,idx)
   if ok2 and mine then
    if builderLogs<41 then log("tile made at row "..tostring(idx)) end
    return mine
   end
   log("tile failed: "..tostring(mine))
  end
  return tile
 end
end

local function unlockedWrap(orig)
 return function(ctrl,tile,...)
  if S.enabled and miTiles[tile] then return false end
  return orig(ctrl,tile,...)
 end
end

local function scanArgsWrap(orig)
 return function(...)
  if S.enabled then
   local n=select("#",...)
   for i=1,math.min(n,4) do
    local a=select(i,...)
    if type(a)=="table" then pcall(preExtend,a) end
   end
  end
  return orig(...)
 end
end

local function costWrap(orig)
 return function(tile,...)
  if miTiles[tile] then return MI_CRAFT_COST end
  return orig(tile,...)
 end
end

local function hookPmu()
 local P=rawget(_G,"PurchaseMenuUtils")
 if type(P)~="table" then return end
 local names={}
 for k,v in pairs(P) do if type(v)=="function" then names[#names+1]=k end end
 for _,k in ipairs(names) do
  local f=P[k]
  if type(f)=="function" and once(P,k) then
   local w=f
   local s8=sfx(k)
   if s8=="30c32f78" then w=builderWrap(w)
   elseif s8=="1a0bd165" then w=costWrap(scanArgsWrap(w))
   elseif s8=="7a229078" then w=unlockedWrap(scanArgsWrap(w))
   else w=scanArgsWrap(w) end
   if w~=f then P[k]=w end
  end
 end
end

-- -------------------------------------------------- pick-up card colour ----
local seenEntry=setmetatable({},{__mode="k"})
local proxies=setmetatable({},{__mode="k"})
local rarityKeys
local function isMiEntry(r)
 local known=seenEntry[r]
 if known~=nil then return known end
 local yes=get(r,"ref")==MI_REF
 seenEntry[r]=yes
 return yes
end
local function miProxy(r)
 local p=proxies[r]
 if p then return p end
 if not rarityKeys then
  rarityKeys={rarity=true}
  local h=hx("rarity")
  if h~=nil then rarityKeys[tostring(h)]=true end
 end
 p=setmetatable({},{__index=function(_,k)
  if k~=nil and (rarityKeys[k] or rarityKeys[tostring(k)]) then return MI_RARITY end
  local ok,o=pcall(function() return r[k] end)
  if ok then return o end
 end})
 proxies[r]=p
 return p
end
local function entryWrap(orig)
 return function(...)
  local res={orig(...)}
  local r=res[1]
  if S.enabled and (type(r)=="table" or type(r)=="userdata") then
   local ok,yes=pcall(isMiEntry,r)
   if ok and yes then
    local ok2,p=pcall(miProxy,r)
    if ok2 and p then res[1]=p end
   end
  end
  return unpack(res,1,table.maxn(res))
 end
end
local function hookCommonItem()
 local CI=rawget(_G,"COMMON_ITEM")
 if type(CI)~="table" then return end
 local names={}
 for k,v in pairs(CI) do if type(v)=="function" then names[#names+1]=k end end
 for _,k in ipairs(names) do
  local f=CI[k]
  if type(f)=="function" and once(CI,k) then CI[k]=entryWrap(f) end
 end
end

-- -------------------------------------------------------- text guard ----
-- A value the text widget rejects raises an error while the grid updates, and that error restarts the whole menu system:
-- the lag, and the crafting table closing. Something on the tile's row does this. The guard draws nothing for that one
-- label instead, and logs what was rejected.
local guardLogs=0
local function setTextGuard(orig)
 return function(self,text,...)
  local ok,err=pcall(orig,self,text,...)
  if ok then return err end
  if guardLogs<30 then
   guardLogs=guardLogs+1
   local okId,id=pcall(function() return self.id end)
   local trace=""
   local dbg=rawget(_G,"debug")
   if type(dbg)=="table" and type(dbg.traceback)=="function" then
    local okT,t=pcall(dbg.traceback,"",2)
    if okT then trace=tostring(t):gsub("[\r\n\t]+"," | "):sub(1,300) end
   end
   log("setText rejected "..type(text).." "..tostring(text).." on "..tostring(okId and id)..": "..tostring(err):sub(1,120).." at"..trace)
  end
  pcall(orig,self,"",...)
 end
end

local function hookTextGuard()
 local L=rawget(_G,"LUI")
 if type(L)~="table" then return end
 for _,key in ipairs(keys("UIText","0x2cc947913cc4d16c")) do
  local okC,cls=pcall(function() return L[key] end)
  if okC and type(cls)=="table" then
   for _,m in ipairs(keys("setText","0xbb794e91c0b6ca4")) do
    local okF,f=pcall(function() return cls[m] end)
    if okF and type(f)=="function" and once(cls,m) then
     pcall(function() cls[m]=setTextGuard(f) end)
     log("text guard on")
    end
   end
  end
 end
end

local function install()
 pcall(hookPmu)
 pcall(hookCommonItem)
 pcall(hookTextGuard)
end

local function tick()
 if not S.enabled then return end
 pcall(install)
 local root=LUI and LUI.GetRoot and LUI.GetRoot()
 if root then pcall(function() root:Wait(2000).onComplete=tick end) end
end

tick()
end)
