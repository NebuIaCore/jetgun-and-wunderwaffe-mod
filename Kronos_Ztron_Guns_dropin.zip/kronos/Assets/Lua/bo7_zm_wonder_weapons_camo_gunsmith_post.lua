-- Enables the native Customize route, exposing only its camo category, for the
-- eight BO7 Zombies Wonder Weapons added by bo7_zm_wonder_weapons_post.lua.
local GLOBAL_NAME = "BO7ZmWonderWeaponsCamoGunsmith"
local prior = rawget(_G, GLOBAL_NAME)
if type(prior) == "table" and type(prior.Restore) == "function" then
    pcall(prior.Restore)
end

local function resolve(object, name)
    if type(object) ~= "table" then return nil end
    local direct = rawget(object, name)
    if type(direct) == "function" then return name, direct end
    local clua = rawget(_G, "CLUA")
    if type(clua) == "table" and type(clua.PushXHash) == "function" then
        local ok, key = pcall(clua.PushXHash, name)
        if ok and key ~= nil then
            local method = rawget(object, key)
            if type(method) == "function" then return key, method end
        end
    end
    return nil
end

local function push(name)
    local clua = rawget(_G, "CLUA")
    if type(clua) == "table" and type(clua.PushXHash) == "function" then
        local ok, key = pcall(clua.PushXHash, name)
        if ok and key ~= nil then return key end
    end
    return name
end

local function safe_member(object, name)
    local clua = rawget(_G, "CLUA")
    local hash_key
    if type(clua) == "table" and type(clua.PushXHash) == "function" then
        local key_ok, key = pcall(clua.PushXHash, name)
        if key_ok then hash_key = key end
    end
    if type(object) == "table" then
        if hash_key ~= nil then
            local value = rawget(object, hash_key)
            if value ~= nil then return value end
        end
        local value = rawget(object, name)
        if value ~= nil then return value end
    end
    if hash_key ~= nil then
        local hash_ok, hash_value = pcall(function() return object[hash_key] end)
        if hash_ok and hash_value ~= nil then return hash_value end
    end
    local plain_ok, plain_value = pcall(function() return object[name] end)
    if plain_ok then return plain_value end
    return nil
end

local function same_ref(left, right)
    if left == right then return left ~= nil end
    local function normalized(value)
        if type(value) ~= "string" then return value end
        local bare = value:gsub("^@", "")
        local clua = rawget(_G, "CLUA")
        if type(clua) == "table" and type(clua.PushXHash) == "function" then
            local ok, hash = pcall(clua.PushXHash, bare)
            if ok and hash ~= nil then return hash end
        end
        return bare
    end
    local normalized_left, normalized_right = normalized(left), normalized(right)
    return normalized_left ~= nil and normalized_left == normalized_right
end

local function is_zombies()
    local conditions = rawget(_G, "CONDITIONS")
    local key, method = resolve(conditions, "IsZM")
    if not key then return false end
    local ok, result = pcall(method)
    return ok and result == true
end

local WEAPON_REF = push("weapon_wonder")
local CLASS_DATA_REF = "sat_wonder_weapon"
-- ztron event wonder weapons: normal weapon classing (sat_lm/sat_ar), camo via
-- their base weapons; accepted by ref + cosmetic ability, no loot id required.
local ZTRON_EVENT_REFS = {
    "sat_lm_ztronjetgun",
    "sat_ar_ztrondg2",
}
local EXPECTED = {
    { "sat_ww_raygun", 121970 },
    { "sat_ww_raygunmark2", 121969 },
    { "sat_ww_firefly", 101506 },
    { "sat_ww_ruby", 101174 },
    { "sat_ww_mantis", 102433 },
    { "sat_ww_locust", 121037 },
    { "sat_ww_hornet", 126903 },
    { "sat_ww_scarab", 129570 },
    { "sat_lm_ztronjetgun", 0 },
    { "sat_ar_ztrondg2", 0 },
}

local function is_ztron_event_ref(ref)
    for _, ztron_ref in ipairs(ZTRON_EVENT_REFS) do
        if same_ref(ref, ztron_ref) then return true end
    end
    return false
end

local function is_expected_ref(ref)
    for _, expected in ipairs(EXPECTED) do
        if same_ref(ref, expected[1]) then return true end
    end
    return false
end

local function expected_ref(ref)
    for _, expected in ipairs(EXPECTED) do
        if same_ref(ref, expected[1]) then return expected[1] end
    end
    return nil
end

local function expected_weapon(data)
    if type(data) ~= "table" and type(data) ~= "userdata" then return false end
    local ref = safe_member(data, "ref")
    if is_ztron_event_ref(ref) then
        if safe_member(data, "canusecosmetic") ~= true then return false end
        if safe_member(data, "isgunsmithdisabled") == true then return false end
        return true
    end
    local loot_id = tonumber(safe_member(data, "lootid"))
    local class_data_ref = safe_member(data, "classdata")
    local menu_class = safe_member(data, "menuclass")
    if not same_ref(class_data_ref, CLASS_DATA_REF)
        or not same_ref(menu_class, WEAPON_REF)
        or safe_member(data, "canusecosmetic") ~= true
        or safe_member(data, "isgunsmithdisabled") == true then
        return false
    end
    for _, expected in ipairs(EXPECTED) do
        if same_ref(ref, expected[1]) and loot_id == expected[2] then return true end
    end
    return false
end

local api = {
    installed = false,
    weapons = EXPECTED,
    Restore = function() return true end,
}
local weapon = rawget(_G, "WEAPON")
local gunsmith = rawget(_G, "GUNSMITH")
local customization_disabled_key, original_customization_disabled = resolve(gunsmith, "iscustomizationdisabled")
local attachments_hidden_key, original_attachments_hidden = resolve(gunsmith, "isattachmentstabhidden")
local hidden_key, original_is_category_hidden = resolve(gunsmith, "iscategoryhidden")
local can_enter_key, original_can_enter = resolve(gunsmith, "canentergunsmith")
if not customization_disabled_key or not attachments_hidden_key or not hidden_key then
    rawset(_G, GLOBAL_NAME, api)
    return
end

local function get_weapon_data(ref)
    if is_zombies() then
        local canonical_ref = expected_ref(ref)
        if canonical_ref then
            local engine = rawget(_G, "Engine")
            local bundle_key, get_bundle = resolve(engine, "GetScriptBundle")
            if bundle_key then
                local ok, result = pcall(get_bundle, "weapondata:" .. canonical_ref)
                if ok and expected_weapon(result) then return result end
            end
        end
    end
    local key, getter = resolve(weapon, "getweapondata")
    if key then
        local ok, result = pcall(getter, ref)
        if ok and result ~= nil then return result end
    end
    -- Native ZM lookup deliberately omits its Wonder bundle fallback. Only
    -- exact requested refs may use the proven direct script-bundle route.
    if is_zombies() and is_expected_ref(ref) then
        local engine = rawget(_G, "Engine")
        local bundle_key, get_bundle = resolve(engine, "GetScriptBundle")
        if bundle_key then
            local ok, result = pcall(get_bundle, "weapondata:" .. expected_ref(ref))
            if ok then return result end
        end
    end
    return nil
end

local function emit_diagnostic(diagnostic)
    local line = string.format(
        "%s loot=%s valid=%s classdata=%s menuclass=%s canUseCosmetic=%s isGunsmithDisabled=%s customizationDisabledFlag=%s nativeIsDisabled=%s nativeCustomizationDisabled=%s nativeCanEnter=%s",
        diagnostic.ref, tostring(diagnostic.lootid), tostring(diagnostic.bundle_valid),
        tostring(diagnostic.classdata), tostring(diagnostic.menuclass),
        tostring(diagnostic.canusecosmetic), tostring(diagnostic.weapon_gunsmith_disabled),
        tostring(diagnostic.weapon_customization_disabled),
        tostring(diagnostic.native_is_disabled), tostring(diagnostic.native_iscustomizationdisabled),
        tostring(diagnostic.native_canentergunsmith))
    local engine = rawget(_G, "Engine")
    local debug_key, engine_debug = resolve(engine, "DebugPrint")
    if debug_key then
        pcall(engine_debug, "[Wonder Weapons Gunsmith] " .. line)
        return
    end
    local global_debug = rawget(_G, "DebugPrint")
    if type(global_debug) == "function" then
        pcall(global_debug, "[Wonder Weapons Gunsmith] " .. line)
        return
    end
    local codhq = rawget(_G, "CODHQ")
    local codhq_key, codhq_debug = resolve(codhq, "DebugPrint")
    if codhq_key then pcall(codhq_debug, "Wonder Weapons Gunsmith", line) end
end

-- Capture the native route gates before installing the narrow override. This
-- is diagnostic only and makes the original reason for the missing entry
-- inspectable without changing native IsDisabled behavior.
api.diagnostics = {}
local is_disabled_key, original_is_disabled = resolve(gunsmith, "IsDisabled")
for _, expected in ipairs(EXPECTED) do
    local ref = expected[1]
    local data = is_zombies() and is_expected_ref(ref) and get_weapon_data(ref) or nil
    local diagnostic = {
        ref = ref, lootid = expected[2], bundle_valid = expected_weapon(data),
    }
    if type(data) == "table" or type(data) == "userdata" then
        diagnostic.classdata = safe_member(data, "classdata")
        diagnostic.menuclass = safe_member(data, "menuclass")
        diagnostic.canusecosmetic = safe_member(data, "canusecosmetic")
        diagnostic.weapon_gunsmith_disabled = safe_member(data, "isgunsmithdisabled")
        diagnostic.weapon_customization_disabled = safe_member(data, "iscustomizationdisabled")
    end
    if is_disabled_key then
        local ok, value = pcall(original_is_disabled, ref)
        if ok then diagnostic.native_is_disabled = value end
    end
    local ok_customization, customization_disabled = pcall(original_customization_disabled, ref)
    if ok_customization then diagnostic.native_iscustomizationdisabled = customization_disabled end
    if can_enter_key then
        local ok, can_enter = pcall(original_can_enter, ref)
        if ok then diagnostic.native_canentergunsmith = can_enter end
    end
    api.diagnostics[#api.diagnostics + 1] = diagnostic
    emit_diagnostic(diagnostic)
end

api.customization_disabled_wrapper = function(ref, ...)
    if is_zombies() and is_expected_ref(ref) and expected_weapon(get_weapon_data(ref)) then return false end
    return original_customization_disabled(ref, ...)
end

api.attachments_hidden_wrapper = function(ref, ...)
    if is_zombies() and is_expected_ref(ref) and expected_weapon(get_weapon_data(ref)) then return true end
    return original_attachments_hidden(ref, ...)
end

api.category_hidden_wrapper = function(category, weapon_ref, ...)
    if is_zombies() and is_expected_ref(weapon_ref) and expected_weapon(get_weapon_data(weapon_ref)) then
        -- The native cosmetic menu includes skins, camo, reticles, charms,
        -- decals and stickers. Wonder weapons expose the camo route only.
        return not same_ref(safe_member(category, "ref"), "camo")
    end
    return original_is_category_hidden(category, weapon_ref, ...)
end

local function restore()
    if rawget(gunsmith, customization_disabled_key) == api.customization_disabled_wrapper then
        rawset(gunsmith, customization_disabled_key, original_customization_disabled)
    end
    if rawget(gunsmith, attachments_hidden_key) == api.attachments_hidden_wrapper then
        rawset(gunsmith, attachments_hidden_key, original_attachments_hidden)
    end
    if rawget(gunsmith, hidden_key) == api.category_hidden_wrapper then
        rawset(gunsmith, hidden_key, original_is_category_hidden)
    end
    api.installed = false
    return true
end

api.Restore = restore
rawset(gunsmith, customization_disabled_key, api.customization_disabled_wrapper)
rawset(gunsmith, attachments_hidden_key, api.attachments_hidden_wrapper)
rawset(gunsmith, hidden_key, api.category_hidden_wrapper)
api.installed = true
rawset(_G, GLOBAL_NAME, api)
