#using scripts\common\utility;
#using scripts\common\weapon;
#using scripts\common\callbacks;
#using scripts\mp\pack_a_punch;

#namespace namespace_ztronpap_61d4;

// pack-a-punch for weapons the machine rejects on ztron (jet gun, wunderwaffe).
// hold USE and press MELEE (with the nexus menu closed) to pack the held weapon
// one tier. uses the same calls as the nexus menu's PaP option:
//   pack_a_punch::get_supports_pap / get_pap_level / pap_weapon
// but skips the supports check, and first swaps the lm/ar ztron variants for
// the map's sat_zm_ variants (the ones with *_pack upgrades in the map data).

autoexec init()
{
    if ( !utility::iszm() )
    {
        return;
    }
    if ( isdefined( level.ztron_pap_v1 ) )
    {
        return;
    }
    level.ztron_pap_v1 = 1;
    level callback::add( #"player_spawned", &ztronpap_on_spawned );
    level thread ztronpap_scan();
}

// covers players who spawned before this script registered its callback
function ztronpap_scan()
{
    for ( i = 0; i < 480; i++ )
    {
        wait 0.25;
        if ( !isdefined( level.players ) || level.players.size == 0 )
        {
            continue;
        }
        foreach ( player in level.players )
        {
            if ( isdefined( player ) && isplayer( player ) )
            {
                player ztronpap_on_spawned( undefined );
            }
        }
        return;
    }
}

function ztronpap_on_spawned( params )
{
    if ( !isdefined( self ) || !isplayer( self ) || isdefined( self.ztron_pap_running ) )
    {
        return;
    }
    self.ztron_pap_running = 1;
    self thread ztronpap_input();
}

function ztronpap_input()
{
    self endon( #"disconnect" );
    melee_was = 0;
    for ( ;; )
    {
        waitframe();
        melee_now = self meleebuttonpressed();
        if ( melee_now && !melee_was && self usebuttonpressed() && !istrue( self.ztron_pap_busy ) )
        {
            self.ztron_pap_busy = 1;
            self thread ztronpap_worker();
        }
        melee_was = melee_now;
    }
}

// pap calls run in their own thread so a script error in them can't kill the input loop
function ztronpap_worker()
{
    self ztronpap_pack_held();
    self.ztron_pap_busy = 0;
}

// map table ref -> sat_zm_ ref it should be swapped to before packing
function ztronpap_zm_ref( root )
{
    if ( root == "sat_lm_ztronjetgun" || root == "sat_lm_ztronjetgun_mp" || root == "sat_lm_ztronjetgun_zm" )
    {
        return "sat_zm_ztronjetgun";
    }
    if ( root == "sat_ar_ztrondg2" || root == "sat_ar_ztrondg2_mp" || root == "sat_ar_ztrondg2_zm" )
    {
        return "sat_zm_ztrondg2";
    }
    return undefined;
}

function ztronpap_ok( w )
{
    return isdefined( w ) && !isnullweapon( w ) && ( !isdefined( level.weaponnone ) || w != level.weaponnone );
}

function ztronpap_build_thread( ref )
{
    if ( isdefined( level.weaponmapdata ) && isdefined( level.weaponmapdata[ ref ] ) && isdefined( level.weaponmapdata[ ref ].assetname ) )
    {
        // same asset -> weapon builder the nexus menu uses
        self.ztron_pap_build = weapon::function_d2c8356dc369d9ce( level.weaponmapdata[ ref ].assetname );
        return;
    }
    self.ztron_pap_build = weapon::buildweapon( ref, getweapondefaultattachments( ref ) );
}

// replace the held lm/ar ztron weapon with the map's sat_zm_ variant, given the
// way nexus gives weapons (load with the other primaries, fire player_weapon_give)
function ztronpap_swap( gun, ref )
{
    self.ztron_pap_build = undefined;
    self thread ztronpap_build_thread( ref );
    waitframe();
    waitframe();
    w = self.ztron_pap_build;
    if ( !ztronpap_ok( w ) )
    {
        iprintln( "^5pap ^1" + ref + " not on this map" );
        return undefined;
    }
    keep = [];
    foreach ( p in self getweaponslist( "primary" ) )
    {
        if ( p != gun )
        {
            keep[ keep.size ] = p;
        }
    }
    keep[ keep.size ] = w;
    self loadweaponsforplayer( keep, 1 );
    for ( i = 0; i < 30; i++ )
    {
        if ( self hasloadedviewweapons( [ w ] ) )
        {
            break;
        }
        wait 0.1;
    }
    self takeweapon( gun );
    self giveweapon( w, undefined, 0, -1, 0 );
    self callback::callback( #"player_weapon_give", { #weapon:w } );
    self givemaxammo( w );
    self switchtoweapon( w );
    wait 0.5;
    iprintln( "^5pap ^7swapped to " + ref );
    return w;
}

function ztronpap_pack_held()
{
    gun = self getcurrentweapon();
    if ( !ztronpap_ok( gun ) )
    {
        iprintln( "^5pap ^1hold a weapon first" );
        return;
    }
    root = weapon::getweaponrootname( gun );
    if ( isdefined( root ) )
    {
        zm_ref = ztronpap_zm_ref( root );
        if ( isdefined( zm_ref ) )
        {
            w = self ztronpap_swap( gun, zm_ref );
            if ( isdefined( w ) )
            {
                gun = w;
            }
        }
    }

    supports = pack_a_punch::get_supports_pap( gun );
    cur = self pack_a_punch::get_pap_level( gun );
    if ( !isdefined( cur ) || cur < 0 )
    {
        cur = 0;
    }
    if ( cur >= 4 )
    {
        iprintln( "^5pap ^7already pap 4" );
        return;
    }
    tier = cur + 1;
    // argument order taken from the nexus menu's own pap call
    packed = self pack_a_punch::pap_weapon( gun, cur, 0, 0, #"essence", 1, 0, tier );
    waitframe();
    if ( ztronpap_ok( packed ) && self hasweapon( packed ) )
    {
        self givemaxammo( packed );
        iprintln( "^5pap ^2tier " + tier + " applied" );
        return;
    }
    // report what the game said so the next fix can target it
    iprintln( "^5pap ^1failed ^7supports=" + ( istrue( supports ) ? "yes" : "no" ) + " tier=" + cur );
    if ( isdefined( root ) )
    {
        iprintln( "^5pap ^7weapon root: " + root );
    }
}
