#using scripts\common\utility;
#using scripts\common\callbacks;
#using scripts\mp\zm\systems\weapons\zm_weap_jetgun;
#using script_3a40b69e86250ac3;
#using script_16ea1b94f0f381b3;

#namespace namespace_ztronguns_71c2;

// Gives the Thrustodyne M23 and the Wunderwaffe DG-2 their original behaviour on any Zombies map.
// The gun scripts come from srv_zm_sat_ztron4, which ztron_share.dll loads filtered down to just them.
// If ztron_share is off, the two includes are missing and Kronos leaves this script unlinked.
//
// What Ztron's map provides and other maps do not, set here instead:
// - the real weapon names the gun scripts ask for (ztron_weapon normally answers);
// - weapon metadata. In Zombies a gun's stats, ammo and projectile come from its sat_zm_* attachment,
//   and that attachment is looked up in level.weaponmetadata, which is loaded per game mode. Other
//   modes' lists do not include these guns, so they stayed in their bare multiplayer form;
// - Pack-a-Punch. The machine only accepts weapons on an allow-list it builds once from the metadata
//   (entries with canpap), and that can run before these entries exist, so they are also added directly;
// - no damage to the player from their own shots with these two guns;
// - no reserve on the Jet Gun. Its clip is its heat: overheating depends on the clip reaching zero, and a
//   reload from reserve would skip that. Its script refills the clip itself as the gun cools;
// - Jet Gun balance: 100 rounds and 35% of the regen before Pack-a-Punch, 200 rounds and the original regen after.
//   ztron_share.dll halves the clip on the sat_zm_ztronjetgun attachment; the regen is handled here;
// - no explosion camera shake. Each shot from these guns is a missile, and weapons.gsc shakes the camera when a missile
//   explodes nearby unless its weapon is on level.var_44cdf5fee6853ac5. Ztron's weapon script fills that list and does
//   not run on other maps, so a close hit shook the screen. weap_raygun.gsc adds the Ray Gun the same way;
// - the Mystery Box and Wonderbar. Each map's wonder list gives the Ray Gun, the Mark 2 and the map's own wonder
//   weapon a weight of 1. Those lists are read-only data, so each spin rolls for these two guns here, at the same
//   odds as one list entry, and hands the result to the box's own forced-item path. ztron_share.dll sets the DG-2's
//   entry to the Ray Guns' rarity.
//
// ztron_share.dll clears the bottomless-clip flag these guns are authored with on Ztron, which is what
// makes them spend ammo at all.

autoexec init()
{
    if ( !utility::iszm() )
    {
        return;
    }
    level.var_2785543070d01fce = "sat_ar_ztrondg2_mp";
    if ( !isdefined( level.var_44cdf5fee6853ac5 ) )
    {
        level.var_44cdf5fee6853ac5 = [];
    }
    // The list holds names in both forms: Ztron's and the Ray Gun's scripts add strings, weapons.gsc adds hashes.
    level.var_44cdf5fee6853ac5 = arraycombineunique( level.var_44cdf5fee6853ac5, [ "sat_lm_ztronjetgun_mp", #"sat_lm_ztronjetgun_mp", "sat_ar_ztrondg2_mp", #"sat_ar_ztrondg2_mp" ] );
    utility::registersharedfunc( #"jetgun", #"overrideweaponname", &ztronguns_jetgun_name );
    level callback::add( #"player_weapon_change", &ztronguns_on_weapon_change );
    level thread ztronguns_setup();
}

function ztronguns_jetgun_name()
{
    return "sat_lm_ztronjetgun_mp";
}

function ztronguns_is_gun( basename )
{
    return basename == "sat_ar_ztrondg2_mp" || basename == "sat_lm_ztronjetgun_mp";
}

function ztronguns_setup()
{
    while ( !isdefined( level.weaponmetadata ) )
    {
        waitframe();
    }
    ztronguns_add_metadata( "sat_ar_ztrondg2_mp", "sat_zm_ar_ztrondg2", "sat_zm_ar_ztrondg2_pack", "sat_zm_ar_ztrondg2_pack2" );
    ztronguns_add_metadata( "sat_lm_ztronjetgun_mp", "sat_zm_ztronjetgun", "sat_zm_ztronjetgun_pack", undefined );
    level.ztronguns_prev_filter = level.var_a44ba6c01eac941;
    level.var_a44ba6c01eac941 = &ztronguns_damage_filter;
    level thread ztronguns_pap_allow();
    level thread ztronguns_jet_tuning();
    level.ztronguns_box_items = [ "zm_sat_weapon_ar_ztrondg2", "zm_sat_weapon_lm_ztronjetgun" ];
    level.ztronguns_box_bases = [ "sat_ar_ztrondg2_mp", "sat_lm_ztronjetgun_mp" ];
    level thread ztronguns_box_keep();
}

// The box stops at the first override that returns a list, and Wonderbar returns one, so the roll below has to come
// first. Gums can register at any time during startup, so this keeps checking. It also adds both guns to the
// weapons the box flashes through while it spins.
function ztronguns_box_keep()
{
    level endon( #"game_ended" );
    count = -1;
    for ( ;; )
    {
        overrides = level.var_cb8cece2b97f9dc;
        if ( !isdefined( overrides ) || overrides.size != count )
        {
            merged = [ &ztronguns_box_roll ];
            if ( isdefined( overrides ) )
            {
                foreach ( func in overrides )
                {
                    merged = arraycombineunique( merged, [ func ] );
                }
            }
            level.var_cb8cece2b97f9dc = merged;
            count = merged.size;
        }
        if ( isdefined( level.var_c94175b5e96b794c ) )
        {
            foreach ( item in level.ztronguns_box_items )
            {
                bundle = getscriptbundle( hashcat( %"itemspawnentry:", item ) );
                if ( isdefined( bundle ) && isdefined( bundle.ref ) )
                {
                    level.var_c94175b5e96b794c[ getxhashasset( bundle.ref ) ] = bundle.worldmodel ?? "tag_origin";
                }
            }
        }
        wait 2;
    }
}

// Runs at the start of every spin, just before the box rolls. self is the box. It never returns a list, so the
// box's own logic still runs; setting the forced item is what makes it give one of these guns as a wonder weapon.
function ztronguns_box_roll( player, str_override_rarity, var_4b076b5c2a1741db )
{
    // Set while the other overrides are being asked below, because this function is one of them.
    if ( isdefined( level.ztronguns_box_asking ) )
    {
        return;
    }
    self.var_aef038a20b4915b3 = undefined;
    if ( !isdefined( level.var_8b6bf63f61fe01f9 ) )
    {
        return;
    }
    level.ztronguns_box_asking = 1;
    override = undefined;
    foreach ( func in level.var_cb8cece2b97f9dc )
    {
        override = [[ func ]]( player, str_override_rarity, var_4b076b5c2a1741db );
        if ( isdefined( override ) )
        {
            break;
        }
    }
    level.ztronguns_box_asking = undefined;
    // Another gum, such as Respin Cycle, asked for a different list.
    if ( isdefined( override ) && override != level.var_8b6bf63f61fe01f9 )
    {
        return;
    }
    // Wonderbar: the spin always lands on the wonder list.
    guaranteed = isdefined( override );
    // This match has the box's wonder weapons turned off.
    if ( !guaranteed && level.var_641b7c91f663ea4f )
    {
        return;
    }
    entries = ztronguns_box_list_size();
    if ( entries <= 0 )
    {
        return;
    }
    items = [];
    foreach ( i, item in level.ztronguns_box_items )
    {
        if ( isdefined( getscriptbundle( hashcat( %"itemspawnentry:", item ) ) ) && !ztronguns_box_has_gun( player, level.ztronguns_box_bases[ i ] ) )
        {
            items[ items.size ] = item;
        }
    }
    if ( guaranteed )
    {
        chance = 1 / ( entries + items.size );
    }
    else
    {
        chance = ztronguns_box_wonder_chance() / 100 / entries;
    }
    roll = randomfloat( 1 );
    foreach ( item in items )
    {
        roll = roll - chance;
        if ( roll < 0 )
        {
            self.var_aef038a20b4915b3 = item;
            level thread ztronguns_box_clear( self );
            return;
        }
    }
}

// The box only reads the forced item during the roll, which finishes within the frame.
function ztronguns_box_clear( box )
{
    waitframe();
    if ( isdefined( box ) )
    {
        box.var_aef038a20b4915b3 = undefined;
    }
}

function ztronguns_box_list_size()
{
    bundle = getscriptbundle( level.var_8b6bf63f61fe01f9 );
    if ( !isdefined( bundle ) && isstring( level.var_8b6bf63f61fe01f9 ) )
    {
        bundle = getscriptbundle( hashcat( %"itemspawnlist:", level.var_8b6bf63f61fe01f9 ) );
    }
    if ( !isdefined( bundle ) || !isarray( bundle.itementries ) )
    {
        return 0;
    }
    return bundle.itementries.size;
}

// The chance that a spin lands on the wonder list, from the same per-round table and round the box uses. self is the box.
function ztronguns_box_wonder_chance()
{
    if ( !isdefined( level.s_magicbox_scaling ) || !isdefined( level.s_magicbox_scaling.var_e706c54ff9d8cadc ) )
    {
        return 0;
    }
    n_round = namespace_9d8e359c3b1041e5::function_57de0ca2e80536a1( self.origin );
    foreach ( row in level.s_magicbox_scaling.var_e706c54ff9d8cadc )
    {
        if ( n_round >= row.minround && n_round <= row.maxround )
        {
            return row.ultrachance ?? 0;
        }
    }
    return 0;
}

function ztronguns_box_has_gun( player, basename )
{
    if ( !isdefined( player.primaryweapons ) )
    {
        return 0;
    }
    foreach ( weapon in player.primaryweapons )
    {
        if ( isdefined( weapon ) && weapon.basename == basename )
        {
            return 1;
        }
    }
    return 0;
}

// The gun's script reads these once at startup from the bare gun, which has 200 rounds. Its arrays are indexed by
// Pack-a-Punch level, so changing entry 0 leaves the packed gun's original regen alone.
function ztronguns_jet_tuning()
{
    level endon( #"game_ended" );
    while ( !isdefined( level.var_c5c65aa83a7189b4 ) || !isdefined( level.var_1bff0cffd060f175 ) )
    {
        waitframe();
    }
    level.var_c5c65aa83a7189b4[ 0 ] = level.var_c5c65aa83a7189b4[ 0 ] * 0.35;
    fraction = makeweapon( "sat_lm_ztronjetgun_mp" ).weaponcustomsettings.recoverthreshold;
    full = level.var_1bff0cffd060f175;
    // An overheated gun can fire again once its clip reaches this level. There is one value for all players, and
    // the script stops checking it when the clip is full, so it has to suit the smallest clip in play: a gun
    // left below it would stay unable to fire.
    for ( ;; )
    {
        threshold = full;
        foreach ( player in level.players )
        {
            if ( isdefined( player.ztronguns_jet_clip ) )
            {
                threshold = min( threshold, player.ztronguns_jet_clip * fraction );
            }
        }
        level.var_1bff0cffd060f175 = threshold;
        wait 0.5;
    }
}

// The machine's list starts empty and can be rebuilt during startup, so this keeps both guns on it.
function ztronguns_pap_allow()
{
    level endon( #"game_ended" );
    roots = [ ztronguns_root( makeweapon( "sat_ar_ztrondg2_mp" ) ), ztronguns_root( makeweapon( "sat_lm_ztronjetgun_mp" ) ) ];
    for ( ;; )
    {
        if ( isdefined( level.var_b6377f00348c4d99 ) )
        {
            foreach ( root in roots )
            {
                level.var_b6377f00348c4d99[ root ] = root;
            }
        }
        wait 2;
    }
}

function ztronguns_root( weaponobj )
{
    root = weaponobj.var_1616e6fbba9a722d;
    if ( !isdefined( root ) || root == "" || root == %"none" )
    {
        root = weaponobj.basename;
    }
    return root;
}

function ztronguns_add_metadata( name, base, pack, packmax )
{
    root = ztronguns_root( makeweapon( name ) );
    // On Ztron itself the mode's own list already has these guns.
    if ( isdefined( level.weaponmetadata[ root ] ) )
    {
        return;
    }
    entry = spawnstruct();
    entry.weapon = name;
    entry.canpap = 1;
    entry.var_a0f67da9669fe547 = [];
    entry.var_6c2dc03affad7ce0 = base;
    entry.var_6ec5e9b28d8ba1f4 = pack;
    if ( isdefined( packmax ) )
    {
        entry.var_c5e9a849426045ca = packmax;
    }
    level.weaponmetadata[ root ] = entry;
}

// Called on the player for every weapon change.
function ztronguns_on_weapon_change( params )
{
    if ( !isplayer( self ) || !isdefined( params.weapon ) || !isweapon( params.weapon ) )
    {
        return;
    }
    if ( !isdefined( self.ztronguns_preloaded ) )
    {
        self.ztronguns_preloaded = 1;
        self thread ztronguns_preload();
    }
    self ztronguns_jet_grab_check( params.weapon );
    if ( ztronguns_is_gun( params.weapon.basename ) )
    {
        self thread ztronguns_upgrade( params.weapon );
    }
    // Without this part the gun's heat script does not run, so the gun keeps its reserve and reloads normally.
    if ( params.weapon.basename == "sat_lm_ztronjetgun_mp" && self getscriptablehaspart( "JetGunVFX" ) )
    {
        self thread ztronguns_jet_watch( params.weapon );
    }
    self notify( #"ztronguns_dg2_bulbs" );
    if ( self getscriptablehaspart( "DG2Vfx" ) )
    {
        if ( params.weapon.basename == "sat_ar_ztrondg2_mp" )
        {
            self.ztronguns_bulb_paped = weaponclipsize( params.weapon ) == 6;
            self thread ztronguns_dg2_bulbs();
        }
        else
        {
            self setscriptablepartstate( "DG2Vfx", "off", 0 );
        }
    }
}

// Run 103: in threads started with an argument, values put in local variables did not stay (the bulb loop read 3 rounds and still
// sent "off" every frame, and the sound thread lost its alias and stopped there). Stock scripts store locals with a different
// instruction than acts does. So these threads take no argument and keep everything on the player, which stock code writes the
// same way.

// The gun's own script starts its bulb glow only for a weapon whose root is t10_ar_p19_dg2, and this gun's root is sat_ar_ztrondg2,
// so the glow never starts. This is that loop: three stages by the rounds left, another set when the clip is 6 (Pack-a-Punched),
// off while reloading or empty.
function ztronguns_dg2_bulbs()
{
    self endon( #"ztronguns_dg2_bulbs" );
    self endon( #"death_or_disconnect" );
    self.ztronguns_bulb_last = "";
    for ( ;; )
    {
        self.ztronguns_bulb_state = "off";
        if ( !self isreloading() )
        {
            self.ztronguns_bulb_rounds = self getcurrentweaponclipammo();
            if ( self.ztronguns_bulb_paped )
            {
                self.ztronguns_bulb_rounds = int( ( self.ztronguns_bulb_rounds + 1 ) / 2 );
            }
            if ( self.ztronguns_bulb_rounds > 3 )
            {
                self.ztronguns_bulb_rounds = 3;
            }
            if ( self.ztronguns_bulb_rounds > 0 )
            {
                self.ztronguns_bulb_state = "vfx_start_" + self.ztronguns_bulb_rounds;
                if ( self.ztronguns_bulb_paped )
                {
                    self.ztronguns_bulb_state = self.ztronguns_bulb_state + "_paped";
                }
            }
        }
        if ( self.ztronguns_bulb_state != self.ztronguns_bulb_last )
        {
            self setscriptablepartstate( "DG2Vfx", self.ztronguns_bulb_state, 0 );
            self.ztronguns_bulb_last = self.ztronguns_bulb_state;
        }
        waitframe();
    }
}

// ztron_share.dll makes the Jet Gun's first raise its inspect animation, which plays silently that way, so the sound is played
// here for as long as that first raise lasts. Swapping away and back is not a new pick-up. Losing the gun and getting it
// back is, and Pack-a-Punch gives a different weapon, so both play it again, as the first raise does.
function ztronguns_jet_grab_check( w )
{
    if ( isdefined( self.ztronguns_jet_grabbed ) && !self hasweapon( self.ztronguns_jet_grabbed ) )
    {
        self.ztronguns_jet_grabbed = undefined;
    }
    if ( w.basename != "sat_lm_ztronjetgun_mp" || ( isdefined( self.ztronguns_jet_grabbed ) && self.ztronguns_jet_grabbed == w ) )
    {
        return;
    }
    self.ztronguns_jet_grabbed = w;
    self thread ztronguns_jet_grab_sound();
}

// Ztron streams its guns in when a player spawns (ztron_weapon::preloadweapons), so their sound banks are in before the first raise.
// Other maps do this only when the box rolls a gun.
function ztronguns_preload()
{
    self endon( #"disconnect" );
    waitframe();
    self loadweaponsforplayer( [ makeweapon( "sat_lm_ztronjetgun_mp" ) ] );
}

function ztronguns_jet_load()
{
    self endon( #"disconnect" );
    self loadweaponsforplayer( [ self.ztronguns_jet_grabbed ], 1 );
}

// The gun's sound bank is streamed in only once the gun is given, about 1.5 s into the first raise in a match, so its sound is
// looked for over the first 3 s. It is then left to play to its end (stopping it with the 3.5 s raise cut it short, Run 105),
// and stopped early only if the player swaps away from the gun.
function ztronguns_jet_grab_sound()
{
    self endon( #"disconnect" );
    // On its own thread: if the load call fails, it takes only that thread with it.
    self thread ztronguns_jet_load();
    self.ztronguns_jet_waited = 0;
    while ( !soundexists( "fly_jetgun_inspect_plr" ) )
    {
        if ( self.ztronguns_jet_waited >= 3 )
        {
            soundexists( "ztron_probe_sound_timeout" ); // TEST, Run 101: ztron_share.dll logs these probes
            return;
        }
        wait 0.05;
        self.ztronguns_jet_waited = self.ztronguns_jet_waited + 0.05;
    }
    soundexists( "ztron_probe_sound_found" );
    self playlocalsound( "fly_jetgun_inspect_plr" );
    soundexists( "ztron_probe_sound_played" );
    self.ztronguns_jet_waited = 0;
    while ( self.ztronguns_jet_waited < 8 )
    {
        if ( self getcurrentweapon().basename != "sat_lm_ztronjetgun_mp" )
        {
            self stoplocalsound( "fly_jetgun_inspect_plr" );
            return;
        }
        wait 0.1;
        self.ztronguns_jet_waited = self.ztronguns_jet_waited + 0.1;
    }
}

// Runs while the player has this Jet Gun. Max Ammo and Pack-a-Punch fill the reserve again, so that stays at zero.
// The gun's script also refills an emptied clip at a fixed 100 rounds a second, in a local value that the regen change
// in ztronguns_jet_tuning cannot reach, so the unpacked gun is held to 35 here. A jump bigger than the script's
// refill step is something else, such as Max Ammo, and is left alone.
function ztronguns_jet_watch( w )
{
    self endon( #"death_or_disconnect" );
    self notify( #"ztronguns_jet_watch" );
    self endon( #"ztronguns_jet_watch" );
    self.ztronguns_jet_clip = weaponclipsize( w );
    limited = w hasattachment( "sat_zm_ztronjetgun" );
    last = self getweaponammoclip( w );
    last_time = gettime();
    allowance = 0;
    while ( self hasweapon( w ) )
    {
        if ( self getweaponammostock( w ) > 0 )
        {
            self setweaponammostock( w, 0 );
        }
        if ( limited )
        {
            clip = self getweaponammoclip( w );
            now = gettime();
            allowance = min( allowance + ( now - last_time ) * 0.035, 3 );
            last_time = now;
            gain = clip - last;
            if ( gain > 0 && gain <= 6 )
            {
                if ( gain > allowance )
                {
                    gain = int( allowance );
                    clip = last + gain;
                    self setweaponammoclip( w, clip );
                }
                allowance = allowance - gain;
            }
            last = clip;
        }
        waitframe();
    }
    self.ztronguns_jet_clip = undefined;
}

// Same check as the game's own attach function, for guns handed out without their attachment.
function ztronguns_upgrade( w )
{
    self endon( #"death_or_disconnect" );
    waitframe();
    if ( !isdefined( level.weaponmetadata ) || self getcurrentweapon() != w )
    {
        return;
    }
    meta = level.weaponmetadata[ ztronguns_root( w ) ];
    if ( !isdefined( meta ) || !isdefined( meta.var_6c2dc03affad7ce0 ) )
    {
        return;
    }
    if ( w hasattachment( meta.var_6c2dc03affad7ce0 ) || w hasattachment( meta.var_6ec5e9b28d8ba1f4 ) )
    {
        return;
    }
    if ( isdefined( meta.var_c5e9a849426045ca ) && w hasattachment( meta.var_c5e9a849426045ca ) )
    {
        return;
    }
    if ( !w canuseattachment( meta.var_6c2dc03affad7ce0 ) )
    {
        return;
    }
    upgraded = w withattachment( meta.var_6c2dc03affad7ce0 );
    self takeweapon( w );
    self giveweapon( upgraded );
    self setweaponammoclip( upgraded, weaponclipsize( upgraded ) );
    self setweaponammostock( upgraded, weaponmaxammo( upgraded ) );
    self switchtoweapon( upgraded );
}

// Returning true makes the game ignore this damage to the player.
function ztronguns_damage_filter( einflictor, eattacker, victim, idamage, idflags, smeansofdeath, fdistance, objweapon, vpoint, vdir, shitloc, psoffsettime, modelindex, partname, extra1, extra2 )
{
    if ( isdefined( eattacker ) && isdefined( victim ) && eattacker == victim && isdefined( objweapon ) && ztronguns_is_gun( objweapon.basename ) )
    {
        return 1;
    }
    if ( isdefined( level.ztronguns_prev_filter ) )
    {
        return [[ level.ztronguns_prev_filter ]]( einflictor, eattacker, victim, idamage, idflags, smeansofdeath, fdistance, objweapon, vpoint, vdir, shitloc, psoffsettime, modelindex, partname, extra1, extra2 );
    }
    return 0;
}
