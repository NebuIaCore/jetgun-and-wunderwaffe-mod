#using scripts\common\utility;
#using scripts\common\callbacks;
#using scripts\mp\currency;
#using scripts\mp\killstreaks\killstreaks;
#using scripts\mp\loot\common_item;
#using scripts\mp\loot\common_item_database;
#using scripts\mp\loot\common_item_killstreak;
#using scripts\mp\utility\lui_game_event_aggregator;

#namespace namespace_zm_minj_restore;

// Brings back the Mutant Injection (killstreak zm_minj), the Mangler transformation. The game still has all of it on
// every Zombies map: the killstreak in the Zombies killstreak list, its item entry and its assets. Only the ways to get it
// are gone: the crafting table sells the Disciple Injection (zm_dinj) instead, and no drop list used by these maps has it.
// This gives it three ways back:
// - a tile on the crafting table's Support tab, added by zm_mutant_injection_menu_post.lua in kronos\Assets\Lua;
// - a reward for a streak of kills without going down;
// - a rare legendary drop from zombies.

autoexec init()
{
    if ( !utility::iszm() )
    {
        return;
    }
    level.zm_minj = spawnstruct();
    level.zm_minj.ref = "zm_minj";
    level.zm_minj.craft_index = 103;   // must match MI_CRAFT_INDEX in the menu Lua; the Void Claw uses 102
    level.zm_minj.craft_cost = 2500;   // salvage, the same as the Disciple Injection; must match MI_CRAFT_COST in the menu Lua
    level.zm_minj.streak_kills = 150;  // kills in a row without going down
    level.zm_minj.rarity = 4;          // legendary; must match MI_RARITY in the menu Lua
    level.zm_minj.drop_percent = 0.2;
    level.zm_minj.drop_percent_special = 2;
    level.zm_minj.drop_percent_elite = 10;
    level.zm_minj.drop_gap_ms = 60000; // the shortest time between two drops
    level.zm_minj.next_drop = 0;
    // TEST: the first kill of the match drops one and the streak is short, to check both without waiting on the odds.
    level.zm_minj.streak_kills = 15;
    level.zm_minj.test_drop = 1;
    level callback::add( #"player_spawned", &zm_minj_on_spawned );
    level callback::add( #"player_laststand", &zm_minj_on_downed );
    level callback::add( #"on_ai_killed", &zm_minj_on_ai_killed );
}

function zm_minj_on_spawned( params )
{
    if ( !istrue( level.zm_minj.hooked ) )
    {
        level.zm_minj.hooked = 1;
        lui_game_event_aggregator::registeronluieventcallback( &zm_minj_craft_response );
    }
}

function zm_minj_on_downed( params )
{
    self.zm_minj_kills = 0;
}

function zm_minj_on_ai_killed( params )
{
    if ( !isdefined( params ) || !isdefined( params.eattacker ) || !isplayer( params.eattacker ) || istrue( self.b_in_spawn_closet ) )
    {
        return;
    }
    player = params.eattacker;
    // Kills made as the Mangler do not earn another one.
    if ( istrue( player.ismutantinjection ) || istrue( player.mutantinjectiontransformed ) )
    {
        return;
    }
    player zm_minj_count_kill();
    zm_minj_roll_drop( self.origin, self.aicategory );
}

function zm_minj_count_kill()
{
    if ( !isdefined( self.zm_minj_kills ) )
    {
        self.zm_minj_kills = 0;
    }
    self.zm_minj_kills++;
    if ( self.zm_minj_kills < level.zm_minj.streak_kills )
    {
        return;
    }
    self.zm_minj_kills = 0;
    // A support item already held is not thrown away: this one lands at the player's feet to swap for if they want.
    if ( !self item_killstreak::hasanykillstreak() && self zm_minj_give() )
    {
        self iprintln( "Kill streak: Mutant Injection" );
        return;
    }
    if ( isdefined( zm_minj_drop( self.origin ) ) )
    {
        self iprintln( "Kill streak: Mutant Injection dropped at your feet" );
    }
}

function zm_minj_roll_drop( origin, category )
{
    if ( istrue( level.zm_minj.test_drop ) )
    {
        level.zm_minj.test_drop = 0;
        zm_minj_drop( origin );
        return;
    }
    if ( gettime() < level.zm_minj.next_drop )
    {
        return;
    }
    percent = level.zm_minj.drop_percent;
    if ( category === "elite" || category === "boss" )
    {
        percent = level.zm_minj.drop_percent_elite;
    }
    else if ( category === "special" )
    {
        percent = level.zm_minj.drop_percent_special;
    }
    if ( randomfloat( 100 ) >= percent )
    {
        return;
    }
    if ( isdefined( zm_minj_drop( origin ) ) )
    {
        level.zm_minj.next_drop = gettime() + level.zm_minj.drop_gap_ms;
    }
}

// The floor glow follows spawnoptions.rarity, and the item stays until picked up.
function zm_minj_drop( origin )
{
    spawnoptions = common_item::items_initspawnoptions_spawnfromposition( origin );
    spawnoptions.rarity = level.zm_minj.rarity;
    spawnoptions.var_fd47e835523b473f = 1;
    spawnoptions.critical = 1;
    return common_item::function_325e28c0fb65c36a( level.zm_minj.ref, 1, spawnoptions );
}

// The same path the crafting table uses for support items, so pickup and swap rules are the game's own.
function zm_minj_give()
{
    bundle = common_item_database::function_a4f0a21951180013( level.zm_minj.ref );
    if ( !isdefined( bundle ) )
    {
        return 0;
    }
    scriptable = getscriptbundlefieldvalue( bundle, #"scriptable" );
    fake_scriptable = { #count:1, #type:scriptable };
    return self common_item::function_2b5e2ff57d5f392( fake_scriptable, 0, 1 );
}

// The game ignores this purchase number because it has no item at that index.
function zm_minj_craft_response( channel, value )
{
    if ( !isdefined( channel ) || channel != "craft_purchase" || !isdefined( value ) || int( value ) != level.zm_minj.craft_index )
    {
        return;
    }
    self thread zm_minj_craft();
}

function zm_minj_craft()
{
    self endon( #"disconnect" );
    response = 3; // not enough salvage
    streak = self killstreaks::getkillstreakinslot( 1 );
    if ( isdefined( streak ) && streak.streakname === level.zm_minj.ref )
    {
        response = 5; // already holding one
    }
    else if ( self currency::get_currency_amount( #"salvage" ) >= level.zm_minj.craft_cost )
    {
        response = 2; // could not give it
        if ( self zm_minj_give() )
        {
            self currency::function_b5fe1e05c892a7f3( #"salvage", level.zm_minj.craft_cost );
            response = 1;
        }
    }
    waitframe();
    self setclientomnvar( "ui_purchasemenu_purchase_response", response );
    self setclientomnvar( "ui_purchasemenu_purchase_response_notify", gettime() );
}
