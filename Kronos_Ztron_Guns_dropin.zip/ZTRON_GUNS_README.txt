Thrustodyne M23 (Jet Gun) and Wunderwaffe DG-2 on all Zombies maps
For cod25-cod.exe sha256 starting b0b12b0e7ec25ce8, run with Kronos's own files (tested with Kronos v1.41).
ztron_share.dll is build v76, pdh.dll is loader 1, zm_ztron_guns.gsc from 2026-11-05.

INSTALL
1. Install or update Kronos and close the game.
2. Extract this zip into the cod25 folder, the one holding cod25-cod.exe. Overwrite when asked.
3. Start the game from the Kronos launcher as usual.

KRONOS AND ITS UPDATES
This mod does not change any Kronos file. pdh.dll is a small loader: the game loads it from its own folder, it passes
every call on to Windows' own pdh.dll, and once Kronos has finished starting it loads ztron_share.dll. Kronos can be
updated with "Update now" as usual, and the mod stays in place.
Older versions of this zip had a patched XINPUT9_1_0.dll. If you used one, press "Update now" once, or reinstall
Kronos, to get Kronos's own file back. This zip does not contain that file.
Where the DLL uses parts of Kronos, it finds them by the text Kronos writes to its log, so a newer Kronos for the same
game build should keep working. If a newer Kronos no longer has one of them, that one feature turns off and
kronos\Logs\ztron_share.log says so.
A game update (a new cod25-cod.exe) needs a new build of this mod, as it does of Kronos.
kronos\Logs\ztron_loader.log shows when and why the loader loaded ztron_share.dll.

SWITCHES
ztron_share.ini            mode=off turns the DLL's work off.
ztron_menu_guns.on         Included. The guns also load in the Zombies lobby, for the firing range and the menu.
                           Delete it to turn that off. Without it the guns are not in the range or the menu.
kronos\settings.json       server.disableGsc must stay false, or the mod does not load.
To remove the mod, delete pdh.dll and ztron_share.dll.

NEEDS FROM THE GAME
These Ztron zones must be in the cod25 folder. They are not in this zip.
zm_sat_ztron4, eng_zm_sat_ztron4, ens_zm_sat_ztron4 and techsets_zm_sat_ztron4 (.ff and .fp), and ww_zm_sat_ztron4.ff.
Kronos supplies srv_zm_sat_ztron4 (.ff and .fp).

KNOWN LIMITS
- On some launches Kronos's weapon table and string limit patches are lost while the game starts. Matches on those
  launches end in a transmission error, and the firing range can crash. The DLL checks every patched spot when it
  loads and runs Kronos's own patch routines again if any were lost. That has been checked against the game's code
  but has not yet run on a launch that needed it. If it cannot repair a launch, a "Ztron guns: bad launch" box tells
  you to fully exit and relaunch.
- Kronos has a filter that cuts the BO6 weapon list in Zombies, and on some launches it did not run. This build
  applies the same cut itself. Sign of that kind of bad launch: kronos\Logs\ztron_share.log says "table count 1104"
  in the lobby (778 is the good number), or poi_reg.log says "netconst register hook FAILED".
- With the Jet Gun or DG-2 in the class, the character in the menus shows with no gun. This is what clears the black
  lobby with the loading indicator (lobby_character_fallback_post.lua). The class itself is not changed. Delete that
  file to go back to the game's behaviour: the character stays missing and the lobby stays black.
- Entering the Zombies lobby takes about 12 seconds longer while the DLL waits for the map before loading the guns.
- Picking the guns in a loadout, the menu preview and camos are not fully checked on this version.
- Mutant Injection is unfinished, and its script does not link on Kronos v1.40 or later. zm_mutant_injection.gsc
  still has its test settings (15-kill streak, a drop on the first kill), and the crafting tile may lag and close the
  table. To remove it, delete zm_mutant_injection.gsc and zm_mutant_injection_menu_post.lua.
- Confirmed in a match: the Jet Gun's pick-up sound, the DG-2's melee swings, and the DG-2's empty inspect using the
  same animation as the inspect with ammo. On the first pick-up in a match the sound starts about 1.5 s late, because
  the game loads the gun's sounds only once it is given, and it plays to its end.
- Not yet confirmed in a match: the DG-2's bulb glow.
- The DLL still writes diagnostic lines to kronos\Logs\ztron_share.log. If kronos\tools\deps\cod25-cod_dump.exe
  exists, it also compares the game's code with it at each launch and writes kronos\Logs\ztron_textdiff_*.log.
  zm_ztron_guns.gsc has three test markers that only show in that log.
